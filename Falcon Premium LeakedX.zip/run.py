#!/usr/bin/env python3
"""
Falcon Premium Bot — stylish purple launcher.
Run: python run.py
"""
from __future__ import annotations

import os
import platform
import sys
import time
from pathlib import Path

# Project root
ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

# Windows ANSI
if sys.platform == "win32":
    try:
        import colorama
        colorama.init()
    except Exception:
        try:
            os.system("")
        except Exception:
            pass


def supports_color() -> bool:
    if os.environ.get("NO_COLOR"):
        return False
    if sys.platform == "win32":
        return True
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


# Gradient palette (dark → light purple)
G = ["\033[38;5;99m", "\033[38;5;105m", "\033[38;5;135m", "\033[38;5;141m", "\033[38;5;177m", "\033[38;5;183m"]
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
UNDER = "\033[4m"
PURPLE = "\033[38;5;141m"
BRIGHT = "\033[38;5;183m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
RED = "\033[31m"


def c(text: str, color: str) -> str:
    if not supports_color():
        return text
    return f"{color}{text}{RESET}"


def clear():
    os.system("cls" if sys.platform == "win32" else "clear")


LOGO = [
    "██╗     ███████╗ █████╗ ██╗  ██╗██╗  ██╗",
    "██║     ██╔════╝██╔══██╗██║ ██╔╝╚██╗██╔╝",
    "██║     █████╗  ███████║█████╔╝  ╚███╔╝ ",
    "██║     ██╔══╝  ██╔══██║██╔═██╗  ██╔██╗ ",
    "███████╗███████╗██║  ██║██║  ██╗██╔╝ ██╗",
    "╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝",
]


def print_banner():
    clear()
    for i, line in enumerate(LOGO):
        color = G[min(i, len(G) - 1)]
        print(c(line, color))
    print()
    tagline = "Falcon Premium Bot  •  Powered by LeakX"
    community = "Join our community  ➜  discord.gg/LeakX"
    width = max(len(line) for line in LOGO)
    print(c(tagline.center(width), BRIGHT + BOLD))
    if supports_color():
        print(c(community.center(width), PURPLE + UNDER + BOLD))
    else:
        print(community.center(width))
    print()


def box_line(text: str, width: int = 52) -> str:
    inner = text[: width - 4].ljust(width - 4)
    return c("│ ", PURPLE) + inner + c(" │", PURPLE)


def print_startup_panel(owners_count: int, db_path: str):
    width = 52
    top = c("┌" + "─" * (width - 2) + "┐", PURPLE)
    bot_ = c("└" + "─" * (width - 2) + "┘", PURPLE)
    print(top)
    print(box_line(f"Python      {platform.python_version()}", width))
    try:
        import discord
        dpy = discord.__version__
    except Exception:
        dpy = "unknown"
    print(box_line(f"discord.py  {dpy}", width))
    print(box_line(f"OS          {platform.system()} {platform.release()}", width))
    print(box_line(f"Owners      {owners_count}", width))
    print(box_line(f"Database    {db_path}", width))
    print(bot_)
    print()


def step(ok: bool, msg: str):
    mark = c("[ ✔ ]", GREEN) if ok else c("[ ✖ ]", RED)
    print(f"  {mark} {c(msg, PURPLE)}")


def animated_steps(bot):
    steps = [
        ("Environment loaded", True),
        ("Database connected", bot.db is not None),
        (f"Cogs loaded ({bot._cogs_loaded}/{bot._cogs_total})", bot._cogs_loaded > 0),
        ("Connecting to Discord...", True),
    ]
    for msg, ok in steps:
        time.sleep(0.35)
        step(ok, msg)
    print()


def print_online_panel(bot):
    width = 52
    top = c("┌" + "─" * (width - 2) + "┐", PURPLE)
    bot_ = c("└" + "─" * (width - 2) + "┘", PURPLE)
    print()
    print(c("  ★ ONLINE", GREEN + BOLD))
    print(top)
    print(box_line(f"Bot       {bot.user} ({bot.user.id})", width))
    print(box_line(f"Servers   {len(bot.guilds)}", width))
    users = sum(g.member_count or 0 for g in bot.guilds)
    print(box_line(f"Users     {users}", width))
    print(box_line(f"Latency   {round(bot.latency * 1000)} ms", width))
    print(box_line(f"Prefix    ,", width))
    print(box_line("discord.gg/LeakX", width))
    print(bot_)
    print()


def main():
    print_banner()

    # Load config early for panel
    from config import validate_config, PRIMARY_OWNER_IDS, DB_PATH, AUTO_RESTART, BOT_TOKEN

    validate_config()
    print_startup_panel(len(PRIMARY_OWNER_IDS), DB_PATH)

    from main import bot, run_bot
    from utils.logger import log_info, log_error, PURPLE as LP, RESET as LR, BOLD as LB

    # Hook ready for online panel
    _original_on_ready = None

    @bot.listen("on_ready")
    async def _launcher_ready():
        print_online_panel(bot)

    # Pre-load: open DB and cogs via setup_hook when bot starts
    # Show loading animation after setup_hook would run — we simulate post-import
    # Actual load happens inside bot.run; show environment first
    step(True, "Environment loaded")
    time.sleep(0.3)

    def _run_once():
        try:
            # Monkey-patch setup_hook to print steps after real load
            original_setup = bot.setup_hook

            async def setup_with_ui():
                await original_setup()
                step(bot.db is not None, "Database connected")
                time.sleep(0.2)
                step(
                    bot._cogs_loaded > 0,
                    f"Cogs loaded ({bot._cogs_loaded}/{bot._cogs_total})",
                )
                if bot._cogs_failed:
                    for name in bot._cogs_failed:
                        step(False, f"Failed cog: {name}")
                time.sleep(0.2)
                step(True, "Connecting to Discord...")
                print()

            bot.setup_hook = setup_with_ui
            run_bot()
        except KeyboardInterrupt:
            if supports_color():
                print(f"\n{LP}{LB}Shutting down... see you at discord.gg/LeakX{LR}\n")
            else:
                print("\nShutting down... see you at discord.gg/LeakX\n")
            try:
                import asyncio
                loop = asyncio.get_event_loop()
                if not loop.is_closed():
                    loop.run_until_complete(bot.close())
            except Exception:
                pass
            sys.exit(0)
        except Exception as e:
            log_error(f"Bot crashed: {e}")
            if AUTO_RESTART:
                log_info("AUTO_RESTART enabled — restarting in 5s...")
                time.sleep(5)
                return True
            raise
        return False

    while True:
        restart = _run_once()
        if not restart:
            break


if __name__ == "__main__":
    main()
