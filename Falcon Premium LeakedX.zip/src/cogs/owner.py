"""
Owner / staff management, no-prefix, blacklist, bot customization.
"""
from datetime import datetime, timedelta

import aiohttp
import discord
from discord.ext import commands

from config import COLOR, PRIMARY_OWNER_ID, PRIMARY_OWNER_IDS
from utils.emojis import DOT, ARROW
from utils.checks import is_bot_owner, is_bot_staff

NP_DURATIONS = [
    ("10 Minutes", "Trial for 10 minutes", timedelta(minutes=10), "10m"),
    ("1 Week", "No prefix for 1 week", timedelta(weeks=1), "1w"),
    ("3 Weeks", "No prefix for 3 weeks", timedelta(weeks=3), "3w"),
    ("1 Month", "No prefix for 1 month", timedelta(days=30), "1mo"),
    ("3 Months", "No prefix for 3 months.", timedelta(days=90), "3mo"),
    ("6 Months", "No prefix for 6 months.", timedelta(days=180), "6mo"),
    ("1 Year", "No prefix for 1 year.", timedelta(days=365), "1y"),
    ("3 Years", "No prefix for 3 years.", timedelta(days=365 * 3), "3y"),
    ("Lifetime", "No prefix permanently.", None, "life"),
]


class NpDurationSelect(discord.ui.Select):
    def __init__(self, bot, target: discord.Member, invoker_id: int):
        self.bot = bot
        self.target = target
        self.invoker_id = invoker_id
        options = [
            discord.SelectOption(label=label, description=desc, value=code)
            for (label, desc, _td, code) in NP_DURATIONS
        ]
        super().__init__(placeholder="Select the duration", min_values=1, max_values=1, options=options)

    async def callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.invoker_id:
            return await interaction.response.send_message(
                "Only the command invoker can use this.", ephemeral=True
            )
        code = self.values[0]
        match = next((d for d in NP_DURATIONS if d[3] == code), None)
        if not match:
            return await interaction.response.send_message("Invalid selection.", ephemeral=True)
        label, _desc, td, _code = match
        if td is None:
            expiry_dt = datetime(9999, 12, 31)
            human = "**Lifetime**"
        else:
            expiry_dt = datetime.now() + td
            human = f"**{label}** (until <t:{int(expiry_dt.timestamp())}:F>)"
        await self.bot.db.execute(
            "INSERT OR REPLACE INTO noprefix (user_id, expiry) VALUES (?, ?)",
            (self.target.id, expiry_dt.isoformat()),
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR,
            description=f"{DOT} Added {self.target.mention} to **No-Prefix** for {human}.",
        )
        for child in self.view.children:
            child.disabled = True
        await interaction.response.edit_message(embed=embed, view=self.view)


class NpDurationView(discord.ui.View):
    def __init__(self, bot, target: discord.Member, invoker_id: int):
        super().__init__(timeout=120)
        self.add_item(NpDurationSelect(bot, target, invoker_id))


class Owner(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="np")
    async def noprefix_cmd(self, ctx, action: str = None, *, rest: str = None):
        if not (await is_bot_owner(self.bot, ctx.author.id) or await is_bot_staff(self.bot, ctx.author.id)):
            return
        action = (action or "").lower()

        if action == "add":
            user = None
            if ctx.message.mentions:
                user = ctx.message.mentions[0]
            elif rest:
                try:
                    user = await commands.MemberConverter().convert(ctx, rest.strip().split()[0])
                except Exception:
                    user = None
            if not user:
                return await ctx.send(
                    embed=discord.Embed(color=COLOR, description=f"{DOT} Usage: `,np add @user`")
                )
            embed = discord.Embed(
                color=COLOR,
                title="Select No Prefix Duration",
                description=f"Choose the duration for how long no-prefix should be enabled for {user.mention}:",
            )
            view = NpDurationView(self.bot, user, ctx.author.id)
            await ctx.send(embed=embed, view=view)
            return

        if action == "remove":
            user = None
            if ctx.message.mentions:
                user = ctx.message.mentions[0]
            elif rest:
                try:
                    user = await commands.MemberConverter().convert(ctx, rest.strip().split()[0])
                except Exception:
                    user = None
            if not user:
                return await ctx.send(
                    embed=discord.Embed(color=COLOR, description=f"{DOT} Usage: `,np remove @user`")
                )
            await self.bot.db.execute("DELETE FROM noprefix WHERE user_id = ?", (user.id,))
            await self.bot.db.commit()
            await ctx.send(
                embed=discord.Embed(
                    color=COLOR, description=f"{DOT} Removed {user.mention} from **No-Prefix**."
                )
            )
            return

        if action == "list":
            async with self.bot.db.execute("SELECT user_id, expiry FROM noprefix") as cursor:
                rows = await cursor.fetchall()
            if not rows:
                return await ctx.send(
                    embed=discord.Embed(color=COLOR, description=f"{DOT} No no-prefix users found.")
                )
            lines = []
            for uid, expiry in rows:
                try:
                    exp_dt = datetime.fromisoformat(expiry)
                    if exp_dt.year >= 9999:
                        when = "Lifetime"
                    else:
                        when = f"<t:{int(exp_dt.timestamp())}:R>"
                except Exception:
                    when = expiry[:10]
                lines.append(f"• <@{uid}> — {when}")
            embed = discord.Embed(color=COLOR, title="No-Prefix Users", description="\n".join(lines))
            return await ctx.send(embed=embed)

        if action == "check":
            user = None
            if ctx.message.mentions:
                user = ctx.message.mentions[0]
            elif rest:
                try:
                    user = await commands.MemberConverter().convert(ctx, rest.strip().split()[0])
                except Exception:
                    user = None
            if not user:
                return await ctx.send(
                    embed=discord.Embed(color=COLOR, description=f"{DOT} Usage: `,np check @user`")
                )
            async with self.bot.db.execute(
                "SELECT expiry FROM noprefix WHERE user_id = ?", (user.id,)
            ) as cursor:
                row = await cursor.fetchone()
            if not row:
                return await ctx.send(
                    embed=discord.Embed(
                        color=COLOR, description=f"{DOT} {user.mention} does not have no-prefix."
                    )
                )
            try:
                exp_dt = datetime.fromisoformat(row[0])
                if exp_dt.year >= 9999:
                    when = "**Lifetime**"
                elif exp_dt < datetime.now():
                    when = "expired"
                else:
                    when = f"<t:{int(exp_dt.timestamp())}:F> (<t:{int(exp_dt.timestamp())}:R>)"
            except Exception:
                when = row[0]
            return await ctx.send(
                embed=discord.Embed(
                    color=COLOR, description=f"{DOT} {user.mention} no-prefix: {when}"
                )
            )

        embed = discord.Embed(
            color=COLOR,
            title="Np Add Command",
            description=(
                "Add user to no-prefix with time options\n\n"
                "**Alt cmd**\nNo Alt cmd\n\n"
                "**Usage**\n`<user>`\n\n"
                "<[] = optional | <> = required • Use Prefix Before Commands."
            ),
        )
        embed.add_field(
            name="Subcommands",
            value="`,np add @user`\n`,np remove @user`\n`,np check @user`\n`,np list`",
            inline=False,
        )
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="setowner", description="(Primary owner) Promote a user to bot owner")
    async def setowner_cmd(self, ctx, user: discord.User):
        if ctx.author.id != PRIMARY_OWNER_ID:
            return await ctx.send(f"{DOT} Only the primary owner can do that.")
        if user.id == PRIMARY_OWNER_ID:
            return await ctx.send(f"{DOT} That user is already the primary owner.")
        await self.bot.db.execute("INSERT OR IGNORE INTO bot_owners (user_id) VALUES (?)", (user.id,))
        await self.bot.db.commit()
        await ctx.send(f"{DOT} **{user}** is now a bot owner.")

    @commands.hybrid_command(name="unsetowner", description="(Primary owner) Remove an owner")
    async def unsetowner_cmd(self, ctx, user: discord.User):
        if ctx.author.id not in PRIMARY_OWNER_IDS:
            return await ctx.send(f"{DOT} Only a primary owner can do that.")
        if user.id in PRIMARY_OWNER_IDS:
            return await ctx.send(f"{DOT} A primary owner cannot be removed.")
        await self.bot.db.execute("DELETE FROM bot_owners WHERE user_id = ?", (user.id,))
        await self.bot.db.commit()
        await ctx.send(f"{DOT} **{user}** is no longer a bot owner.")

    @commands.hybrid_command(name="owners", description="List all bot owners")
    async def owners_cmd(self, ctx):
        async with self.bot.db.execute("SELECT user_id FROM bot_owners") as cur:
            rows = await cur.fetchall()
        lines = [f"{ARROW} <@{oid}> — `{oid}` (Primary)" for oid in PRIMARY_OWNER_IDS]
        for (uid,) in rows:
            if uid in PRIMARY_OWNER_IDS:
                continue
            lines.append(f"{ARROW} <@{uid}> — `{uid}`")
        embed = discord.Embed(color=COLOR, title="Bot Owners", description="\n".join(lines))
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="setstaff", description="(Owner) Promote a user to bot staff")
    async def setstaff_cmd(self, ctx, user: discord.User):
        if not await is_bot_owner(self.bot, ctx.author.id):
            return await ctx.send(f"{DOT} Owner only.")
        await self.bot.db.execute("INSERT OR IGNORE INTO bot_staff (user_id) VALUES (?)", (user.id,))
        await self.bot.db.commit()
        await ctx.send(f"{DOT} **{user}** is now bot staff.")

    @commands.hybrid_command(name="unsetstaff", description="(Owner) Remove a staff member")
    async def unsetstaff_cmd(self, ctx, user: discord.User):
        if not await is_bot_owner(self.bot, ctx.author.id):
            return await ctx.send(f"{DOT} Owner only.")
        await self.bot.db.execute("DELETE FROM bot_staff WHERE user_id = ?", (user.id,))
        await self.bot.db.commit()
        await ctx.send(f"{DOT} **{user}** is no longer bot staff.")

    @commands.hybrid_command(name="staff", description="List all bot staff")
    async def staff_cmd(self, ctx):
        async with self.bot.db.execute("SELECT user_id FROM bot_staff") as cur:
            rows = await cur.fetchall()
        if not rows:
            desc = f"{DOT} No staff members."
        else:
            desc = "\n".join([f"{ARROW} <@{uid}> — `{uid}`" for (uid,) in rows])
        embed = discord.Embed(color=COLOR, title="Bot Staff", description=desc)
        await ctx.send(embed=embed)

    @commands.command(name="c")
    async def customize_cmd(self, ctx, action: str = None, *, url: str = None):
        if not await is_bot_owner(self.bot, ctx.author.id):
            return
        if not action:
            return await ctx.send(
                embed=discord.Embed(
                    color=COLOR,
                    description=(
                        f"{DOT} Customization\n"
                        f"{ARROW} `,c a <url|attachment>` — change bot avatar\n"
                        f"{ARROW} `,c b <url|attachment>` — change bot banner"
                    ),
                )
            )
        action = action.lower()
        if action not in ("a", "avatar", "b", "banner"):
            return await ctx.send(f"{DOT} Use `a` (avatar) or `b` (banner).")
        img_url = url
        if not img_url and ctx.message.attachments:
            img_url = ctx.message.attachments[0].url
        if not img_url:
            return await ctx.send(f"{DOT} Provide an image URL or attach an image.")
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(img_url) as resp:
                    if resp.status != 200:
                        return await ctx.send(f"{DOT} Failed to download image (HTTP {resp.status}).")
                    data = await resp.read()
            if action in ("a", "avatar"):
                await self.bot.user.edit(avatar=data)
                kind = "avatar"
            else:
                await self.bot.user.edit(banner=data)
                kind = "banner"
            await ctx.send(
                embed=discord.Embed(
                    color=COLOR, description=f"{DOT} Bot {kind} updated successfully."
                )
            )
        except discord.HTTPException as e:
            await ctx.send(f"{DOT} Discord error: {e}")
        except Exception as e:
            await ctx.send(f"{DOT} Error: {e}")

    @commands.command(name="blacklist", aliases=["bl"])
    async def blacklist_user_cmd(self, ctx, action: str = None, *, rest: str = None):
        if not await is_bot_staff(self.bot, ctx.author.id):
            return
        action = (action or "").lower()
        if action == "add":
            user = ctx.message.mentions[0] if ctx.message.mentions else None
            if not user:
                return await ctx.send(f"{DOT} Usage: `,blacklist add @user [reason]`")
            if user.id in PRIMARY_OWNER_IDS:
                return await ctx.send(f"{DOT} Cannot blacklist a primary owner.")
            reason_parts = (rest or "").split(maxsplit=1)
            reason = reason_parts[1] if len(reason_parts) > 1 else "No reason"
            await self.bot.db.execute(
                "INSERT OR REPLACE INTO user_blacklist (user_id, reason, by_user, at) VALUES (?, ?, ?, ?)",
                (user.id, reason, ctx.author.id, datetime.now().isoformat()),
            )
            await self.bot.db.commit()
            await ctx.send(
                embed=discord.Embed(
                    color=COLOR,
                    description=(
                        f"{DOT} {user.mention} has been **blacklisted** from the bot.\n"
                        f"{ARROW} Reason: {reason}"
                    ),
                )
            )
        elif action == "remove":
            user = ctx.message.mentions[0] if ctx.message.mentions else None
            if not user:
                return await ctx.send(f"{DOT} Usage: `,blacklist remove @user`")
            await self.bot.db.execute("DELETE FROM user_blacklist WHERE user_id = ?", (user.id,))
            await self.bot.db.commit()
            await ctx.send(
                embed=discord.Embed(
                    color=COLOR,
                    description=f"{DOT} {user.mention} has been removed from the blacklist.",
                )
            )
        elif action == "list":
            async with self.bot.db.execute("SELECT user_id, reason FROM user_blacklist") as cur:
                rows = await cur.fetchall()
            if not rows:
                return await ctx.send(f"{DOT} No blacklisted users.")
            desc = "\n".join([f"{ARROW} <@{uid}> — {reason}" for uid, reason in rows])
            await ctx.send(embed=discord.Embed(color=COLOR, title="Bot Blacklist", description=desc))
        else:
            await ctx.send(
                embed=discord.Embed(
                    color=COLOR,
                    description=(
                        f"{DOT} Usage:\n"
                        f"{ARROW} `,blacklist add @user [reason]`\n"
                        f"{ARROW} `,blacklist remove @user`\n"
                        f"{ARROW} `,blacklist list`"
                    ),
                )
            )


async def setup(bot):
    await bot.add_cog(Owner(bot))
