"""
Invite tracking commands.
"""
from datetime import datetime

import discord
from discord.ext import commands

from config import COLOR
from utils.emojis import DOT, ARROW, get_status_emoji
from utils.database import update_user, get_user_data


class Invites(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="invites")
    async def invites_cmd(self, ctx, user: discord.Member = None):
        user = user or ctx.author
        joins, left, bonus, _, _, _, _, _, _ = await get_user_data(self.bot, user.id)
        total = joins - left + bonus
        embed = discord.Embed(color=COLOR)
        embed.set_author(name=f"{user.name}'s Invites Stats", icon_url=user.display_avatar.url)
        embed.description = f"{user.name} currently has **{total}** invites."
        embed.add_field(
            name="Total:",
            value=(
                f"{ARROW} ・ **Joins : {joins}**\n"
                f"{ARROW} ・ **Left : {left}**\n"
                f"{ARROW} ・ **Bonus : {bonus}**"
            ),
            inline=False,
        )
        embed.add_field(
            name="Other:",
            value=f"{ARROW} ・ **Fake : 0**\n{ARROW} ・ **Rejoins : 0**",
            inline=False,
        )
        embed.set_footer(
            text=f"Requested by {ctx.author.name} • Today at {datetime.now().strftime('%I:%M %p')}",
            icon_url=self.bot.user.display_avatar.url,
        )
        await ctx.send(embed=embed)

    @commands.command(name="i")
    async def i_cmd(self, ctx, user: discord.Member = None):
        await self.invites_cmd(ctx, user)

    @commands.command(name="inviter")
    async def inviter_cmd(self, ctx, user: discord.Member = None):
        user = user or ctx.author
        async with self.bot.db.execute(
            "SELECT inviter_id, joined_at FROM invite_tracker WHERE invitee_id = ?", (user.id,)
        ) as cursor:
            row = await cursor.fetchone()
        embed = discord.Embed(color=COLOR)
        embed.set_author(name="Inviter information")
        if row:
            inviter_id, joined_at_str = row
            inviter_mention = f"<@!{inviter_id}>"
            try:
                joined_dt = datetime.fromisoformat(joined_at_str)
                delta = datetime.now() - joined_dt
                days = delta.days
                joined_str = "Today" if days == 0 else ("1 day ago" if days == 1 else f"{days} days ago")
            except Exception:
                joined_str = "Unknown"
            embed.description = f"**! {user.name}** was invited by {inviter_mention}\nJoined : {joined_str}"
        else:
            embed.description = (
                f"**! {user.name}** — No inviter data found.\n"
                "They may have joined before tracking started."
            )
        embed.set_footer(
            text=f"Today at {datetime.now().strftime('%I:%M %p')}",
            icon_url=self.bot.user.display_avatar.url,
        )
        await ctx.send(embed=embed)

    @commands.command(name="invited")
    async def invited_cmd(self, ctx, user: discord.Member = None):
        user = user or ctx.author
        async with self.bot.db.execute(
            "SELECT invitee_id, joined_at FROM invite_tracker WHERE inviter_id = ?", (user.id,)
        ) as cursor:
            rows = await cursor.fetchall()
        if not rows:
            embed = discord.Embed(color=COLOR)
            embed.set_author(name=f"Invited list of ! {user.name}")
            embed.description = "This user has not invited anyone yet."
            embed.set_footer(text="Page 1/1", icon_url=self.bot.user.display_avatar.url)
            return await ctx.send(embed=embed)
        entries = []
        for idx, (invitee_id, _) in enumerate(rows, start=1):
            member = ctx.guild.get_member(invitee_id)
            name = member.name if member else f"Unknown ({invitee_id})"
            status_emoji = get_status_emoji(member)
            entries.append((idx, name, status_emoji))
        page_size = 10
        pages = [entries[i : i + page_size] for i in range(0, len(entries), page_size)]
        total_pages = len(pages)
        current_page = [0]

        def build_embed(page_idx):
            embed = discord.Embed(color=COLOR)
            embed.set_author(
                name=f"Invited list of ! {user.name}", icon_url=user.display_avatar.url
            )
            lines = [
                f"**#{idx}** •! **{name}** • {status}"
                for idx, name, status in pages[page_idx]
            ]
            embed.description = "\n".join(lines)
            embed.set_footer(
                text=f"Page {page_idx + 1}/{total_pages}",
                icon_url=self.bot.user.display_avatar.url,
            )
            return embed

        class PaginationView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=60)
                self.update_buttons()

            def update_buttons(self):
                self.first_btn.disabled = current_page[0] == 0
                self.prev_btn.disabled = current_page[0] == 0
                self.next_btn.disabled = current_page[0] == total_pages - 1
                self.last_btn.disabled = current_page[0] == total_pages - 1

            @discord.ui.button(emoji="⏮️", style=discord.ButtonStyle.secondary)
            async def first_btn(self, interaction, button):
                if interaction.user != ctx.author:
                    return await interaction.response.send_message("Not your command!", ephemeral=True)
                current_page[0] = 0
                self.update_buttons()
                await interaction.response.edit_message(embed=build_embed(current_page[0]), view=self)

            @discord.ui.button(emoji="⏪", style=discord.ButtonStyle.secondary)
            async def prev_btn(self, interaction, button):
                if interaction.user != ctx.author:
                    return await interaction.response.send_message("Not your command!", ephemeral=True)
                current_page[0] = max(0, current_page[0] - 1)
                self.update_buttons()
                await interaction.response.edit_message(embed=build_embed(current_page[0]), view=self)

            @discord.ui.button(emoji="⏹️", style=discord.ButtonStyle.danger)
            async def stop_btn(self, interaction, button):
                if interaction.user != ctx.author:
                    return await interaction.response.send_message("Not your command!", ephemeral=True)
                for child in self.children:
                    child.disabled = True
                await interaction.response.edit_message(view=self)
                self.stop()

            @discord.ui.button(emoji="⏩", style=discord.ButtonStyle.secondary)
            async def next_btn(self, interaction, button):
                if interaction.user != ctx.author:
                    return await interaction.response.send_message("Not your command!", ephemeral=True)
                current_page[0] = min(total_pages - 1, current_page[0] + 1)
                self.update_buttons()
                await interaction.response.edit_message(embed=build_embed(current_page[0]), view=self)

            @discord.ui.button(emoji="⏭️", style=discord.ButtonStyle.secondary)
            async def last_btn(self, interaction, button):
                if interaction.user != ctx.author:
                    return await interaction.response.send_message("Not your command!", ephemeral=True)
                current_page[0] = total_pages - 1
                self.update_buttons()
                await interaction.response.edit_message(embed=build_embed(current_page[0]), view=self)

        view = PaginationView() if total_pages > 1 else discord.ui.View()
        await ctx.send(embed=build_embed(0), view=view)

    @commands.command(name="inviteinfo")
    async def inviteinfo(self, ctx, user: discord.Member = None):
        user = user or ctx.author
        try:
            guild_invites = await ctx.guild.invites()
        except Exception:
            return await ctx.send("❌ I don't have permission to view invites.")
        user_invites = [inv for inv in guild_invites if inv.inviter and inv.inviter.id == user.id]
        embed = discord.Embed(color=COLOR)
        embed.set_author(name=f"Invite codes for {user.name}", icon_url=user.display_avatar.url)
        if not user_invites:
            embed.description = f"{DOT} {user.mention} has no active invite codes."
        else:
            lines = []
            for inv in user_invites:
                exp = f"<t:{int(inv.expires_at.timestamp())}:R>" if inv.expires_at else "Never"
                lines.append(f"{DOT} `{inv.code}` — **{inv.uses}** uses — Expires: {exp}")
            embed.description = "\n".join(lines)
        embed.set_footer(
            text=f"Today at {datetime.now().strftime('%I:%M %p')}",
            icon_url=self.bot.user.display_avatar.url,
        )
        await ctx.send(embed=embed)

    @commands.command(name="addinvites")
    @commands.has_permissions(administrator=True)
    async def addinvites(self, ctx, user: discord.Member, amount: int):
        """Add invites to a user

        Usage: ,addinvites <user> <amount>
        Example: ,addinvites @John 5"""
        await update_user(self.bot, user.id, bonus=amount)
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} Added **{amount}** invites to {user.mention}."
        )
        await ctx.send(embed=embed)

    @commands.command(name="removeinvites")
    @commands.has_permissions(administrator=True)
    async def removeinvites(self, ctx, user: discord.Member, amount: int):
        """Remove invites from a user

        Usage: ,removeinvites <user> <amount>
        Example: ,removeinvites @John 3"""
        await update_user(self.bot, user.id, bonus=-amount)
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} Removed **{amount}** invites from {user.mention}."
        )
        await ctx.send(embed=embed)

    @commands.command(name="clearinvites")
    @commands.has_permissions(administrator=True)
    async def clearinvites(self, ctx, user: discord.Member = None):
        if user:
            await self.bot.db.execute(
                "UPDATE users SET joins=0, left=0, bonus=0 WHERE user_id=?", (user.id,)
            )
            await self.bot.db.commit()
            embed = discord.Embed(
                color=COLOR, description=f"{DOT} Successfully reset invites for {user.mention}."
            )
        else:
            await self.bot.db.execute("UPDATE users SET joins=0, left=0, bonus=0")
            await self.bot.db.commit()
            embed = discord.Embed(
                color=COLOR,
                description=f"{DOT} Successfully reset **all** members' invites in this guild.",
            )
        await ctx.send(embed=embed)

    @commands.command(name="resetmyinvites")
    async def resetmyinvites(self, ctx):
        await self.bot.db.execute(
            "UPDATE users SET joins=0, left=0, bonus=0 WHERE user_id=?", (ctx.author.id,)
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR,
            description=f"{DOT} Your invite stats have been reset, {ctx.author.mention}.",
        )
        await ctx.send(embed=embed)

    @commands.command(name="setaltthreshold")
    @commands.has_permissions(manage_guild=True)
    async def setaltthreshold(self, ctx, days: int):
        await self.bot.db.execute(
            "INSERT INTO guild_settings (guild_id, alt_threshold) VALUES (?, ?) "
            "ON CONFLICT(guild_id) DO UPDATE SET alt_threshold=excluded.alt_threshold",
            (ctx.guild.id, days),
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} Alt threshold set to **{days} days**."
        )
        await ctx.send(embed=embed)

    @commands.command(name="unsetaltthreshold")
    @commands.has_permissions(manage_guild=True)
    async def unsetaltthreshold(self, ctx):
        await self.bot.db.execute(
            "UPDATE guild_settings SET alt_threshold=NULL WHERE guild_id=?", (ctx.guild.id,)
        )
        await self.bot.db.commit()
        embed = discord.Embed(color=COLOR, description=f"{DOT} Alt threshold disabled.")
        await ctx.send(embed=embed)

    @commands.command(name="setinviterole")
    @commands.has_permissions(manage_guild=True)
    async def setinviterole(self, ctx, role: discord.Role, invites: int):
        """Set role reward at invite milestone

        Usage: ,setinviterole <role> <invites>
        Example: ,setinviterole @Gold 10"""
        await self.bot.db.execute(
            "INSERT OR REPLACE INTO invite_roles (guild_id, role_id, required_invites) VALUES (?, ?, ?)",
            (ctx.guild.id, role.id, invites),
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR,
            description=f"{DOT} Members will receive {role.mention} when they reach **{invites}** invites.",
        )
        await ctx.send(embed=embed)

    @commands.command(name="unsetinviterole")
    @commands.has_permissions(manage_guild=True)
    async def unsetinviterole(self, ctx, role: discord.Role):
        await self.bot.db.execute(
            "DELETE FROM invite_roles WHERE guild_id=? AND role_id=?", (ctx.guild.id, role.id)
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} Invite role reward for {role.mention} removed."
        )
        await ctx.send(embed=embed)

    @commands.command(name="viewinviteroles")
    async def viewinviteroles(self, ctx):
        async with self.bot.db.execute(
            "SELECT role_id, required_invites FROM invite_roles WHERE guild_id=? ORDER BY required_invites ASC",
            (ctx.guild.id,),
        ) as cur:
            rows = await cur.fetchall()
        embed = discord.Embed(color=COLOR, title="🏆 Invite Role Rewards")
        if not rows:
            embed.description = f"{DOT} No invite role rewards configured."
        else:
            embed.description = "\n".join(
                [f"{DOT} <@&{r[0]}> — **{r[1]}** invites required" for r in rows]
            )
        await ctx.send(embed=embed)

    @commands.command(name="bonus")
    @commands.has_permissions(administrator=True)
    async def bonus(self, ctx, user: discord.Member, amount: int):
        await update_user(self.bot, user.id, bonus=amount)


async def setup(bot):
    await bot.add_cog(Invites(bot))
