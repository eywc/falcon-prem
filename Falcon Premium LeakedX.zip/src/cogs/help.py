"""
Help command with dropdown categories (1:1 clone of original).
"""
import discord
from discord.ext import commands

from config import (
    COLOR, CLIENT_ID, PRIMARY_OWNER_ID, SUPPORT_SERVER_URL,
    VOTE_URL, DASHBOARD_URL, TOS_URL, PRIVACY_URL,
)
from utils.emojis import (
    DOT, ARROW, E_NEWS, E_PREMIUM, E_INVITE, E_MSG, E_VOICE, E_ROLE, E_LB,
    E_GW, E_TIMER, E_GREET, E_MOD, E_MANAGE, E_POLL, E_UTILITY, E_CONTACT,
)
from utils.checks import is_bot_owner


# Auto emoji helpers (owner feature)
SECTION_KEYWORDS = [
    ["premium", "vip", "crown", "diamond", "gem", "star", "sparkle", "gold", "rich"],
    ["invite", "invites", "envelope", "mail", "letter", "join", "member", "add", "plus", "people"],
    ["message", "msg", "chat", "talk", "speech", "bubble", "comment", "text", "say", "type"],
    ["voice", "vc", "mic", "microphone", "audio", "sound", "speak", "headphone", "music"],
    ["role", "autorole", "tag", "badge", "label", "rank"],
    ["leaderboard", "lb", "trophy", "top", "winner", "first", "medal", "rank", "podium"],
    ["giveaway", "gift", "gw", "present", "tada", "party", "celebrate", "confetti"],
    ["timer", "time", "clock", "alarm", "hourglass", "stopwatch", "watch"],
    ["greet", "welcome", "wave", "hello", "hi", "hey", "handshake"],
    ["mod", "ban", "hammer", "shield", "gavel", "kick", "lock", "staff", "police", "guard", "admin"],
    ["gear", "setting", "settings", "manage", "config", "tool", "wrench", "cog", "system"],
    ["poll", "vote", "chart", "bar", "stats", "graph", "ballot", "survey"],
    ["util", "utility", "tool", "wrench", "ping", "info", "search", "lens", "magnify"],
    ["contact", "support", "credit", "credits", "link", "owner", "heart", "team", "crew", "thanks", "love"],
]


def _smart_pick_emojis(guild_emojis):
    chosen = []
    used_ids = set()
    available = list(guild_emojis)
    for keywords in SECTION_KEYWORDS:
        match = None
        for kw in keywords:
            for e in available:
                if e.id in used_ids:
                    continue
                if kw in e.name.lower():
                    match = e
                    break
            if match:
                break
        if match:
            used_ids.add(match.id)
            chosen.append(str(match))
        else:
            chosen.append("")
    leftovers = [e for e in available if e.id not in used_ids]
    li = 0
    for i in range(len(chosen)):
        if not chosen[i] and li < len(leftovers):
            chosen[i] = str(leftovers[li])
            used_ids.add(leftovers[li].id)
            li += 1
    return chosen


async def get_guild_dropdown_emojis(bot, guild_id):
    if guild_id is None:
        return None
    async with bot.db.execute(
        "SELECT emojis FROM guild_help_emojis WHERE guild_id = ?", (guild_id,)
    ) as cur:
        row = await cur.fetchone()
        if row and row[0]:
            return row[0].split("|")
    return None


async def store_guild_dropdown_emojis(bot, guild):
    pool = [e for e in guild.emojis if not e.animated]
    if not pool:
        pool = list(guild.emojis)
    if not pool:
        return False
    chosen = _smart_pick_emojis(pool)
    if not any(chosen):
        return False
    await bot.db.execute(
        "INSERT OR REPLACE INTO guild_help_emojis (guild_id, emojis) VALUES (?, ?)",
        (guild.id, "|".join(chosen)),
    )
    await bot.db.commit()
    return True


HELP_SECTIONS = {
    "premium": {
        "emoji": E_PREMIUM,
        "label": "Premium utility",
        "title": "Premium",
        "description": "Displays premium command usage",
        "commands": [
            (",premium activate", None),
            (",premium gift", None),
            (",premium view user", None),
            (",premium view guild", None),
        ],
    },
    "invites": {
        "emoji": E_INVITE,
        "label": "Invite tracking",
        "title": "Invite logger/ Invite tracker",
        "description": "Tracks server invites",
        "commands": [
            (",invites", "Displays the invites stats of a user in this guild"),
            (",inviter", "Displays the inviter of a server member"),
            (",invited", "Displays the invited list of a member"),
            (",inviteinfo", "Displays the active invite code(s) of a user in this guild"),
            (",setjoinchannel", "Set the welcome channel! All invites welcome message will appear there"),
            (",addinvites", "Adds a number of invites to a user !"),
            (",removeinvites", "Removes a number of invites from a user !"),
            (",unsetwelcomechannel", "Unset the welcome channel! Note that this command will disable the welcome messages"),
            (",setleave", "Sets the member leave channel"),
            (",unsetleavechannel", "Unsets the member leave channel! Note that this will disable member leave messages"),
            (",setaltthreshold", "Customize fake invites count duration"),
            (",unsetaltthreshold", "Disable custom alt threshold"),
            (",setinviterole", "Setup invite role reward, the bot will give roles to inviters when reaching specified invites count"),
            (",unsetinviterole", "Remove your customized invite role configuration"),
            (",viewinviteroles", "View you customized invite role configuration"),
            (",clearinvites", "Resets everyone's invites or a user's invites statistics in this guild"),
            (",resetmyinvites", "Clears your own invites in this guild (no permissions required)"),
            (",setjoinmessage", "Set a custom join message"),
            (",setleavemessage", "Set a custom leave message"),
            (",setvanitymessage", "Set a custom vanity join message"),
            (",unsetjoinmessage", "Deletes your custom join message"),
            (",unsetleavemessage", "Deletes your custom leave message"),
            (",unsetvanitymessage", "Deletes your custom vanity message"),
            (",variables", "Displays the variables so that you can use them in custom welcome message"),
            (",testmsg", "Displays your custom join message which you enter as an argument!"),
            (",leaderboard invites", "Displays the top 10 inviters in this guild"),
        ],
    },
    "messages": {
        "emoji": E_MSG,
        "label": "Messages",
        "title": "Messages",
        "description": "Tracks user message counts",
        "commands": [
            (",messages", "Displays the number of messages sent by you or a user"),
            (",addmessages", "Adds the specified number of messages to a user"),
            (",removemessages", "Removes the specified number of messages to a user"),
            (",blacklistchannel", "Blacklists a channel , I wont count messages from that channel"),
            (",unblacklistchannel", "Unblacklists a channel"),
            (",blacklistedchannels", "Displays the blacklisted channels of a guild"),
            (",blacklistcategory", "Blacklists a category, I wont count messages sent in that category"),
            (",unblacklistcategory", "Unblacklists a category"),
            (",blacklistedcategories", "Displays the blacklisted categories of a guild"),
            (",setmessagerole", "Setup messages role, the bot will give roles to members when reaching specified messages count"),
            (",unsetmessagerole", "Remove your customized message role configuration"),
            (",viewmessageroles", "View you customized message role configuration"),
            (",clearmsgs", "Resets everyone's messages or a user's messages in this guild"),
            (",resetmymessages", "Resets your own messages that you sent in this guild (no permissions required)"),
            (",setresettime weeklymessage", "Customize your weekly messages reset time"),
            (",setresettime dailymessage", "Customize your daily messages reset time"),
            (",leaderboard weeklymessages", "Displays the top 10 active messengers in this guild"),
            (",leaderboard messages", "Displays the top 10 messengers in this guild"),
            (",leaderboard dailymessages", "Displays the top 10 active messengers in this guild"),
        ],
    },
    "voice": {
        "emoji": E_VOICE,
        "label": "Voice",
        "title": "Voice state tracking",
        "description": "Logs voice channel durations",
        "commands": [
            (",vc", "Displays the voice state stats of a user"),
            (",addvctime", "Add voice time to All time, daily and weekly fields of a user"),
            (",reducevctime", "Reduce voice time from All time, daily and weekly fields to a user"),
            (",clearvoice", "Resets everyone's voice state stats or a user's voice state stats in this guild"),
            (",resetmyvoice", "Resets your own voice state record in this guild (no permissions required)"),
            (",setresettime dailyvoice", "Customize your daily voice state reset time"),
            (",setresettime weeklyvoice", "Customize your weekly voice state reset time"),
            (",leaderboard weeklyvoice", "Displays the top 10 voice state members in this guild"),
            (",leaderboard voice", "Displays the top 10 voice state members in this guild"),
            (",leaderboard dailyvoice", "Displays the top 10 voice state members in this guild"),
        ],
    },
    "autoroles": {
        "emoji": "<:fp_premium:1569572440269398098>",
        "label": "Auto Roles",
        "title": "Auto Roles",
        "description": "Automatically assign roles to new users",
        "commands_with_header": True,
        "commands": [
            (",autorole", "Get list of all autorole commands"),
            (",setautorole", "Set autorole for humans and bots"),
            (",unsetautorole", "Delete an autorole"),
            (",configscreening", "This feature will add role to users after they complete membership screening"),
            (",viewautoroles", "Displays a guild's autoroles"),
        ],
    },
    "liveleaderboards": {
        "emoji": E_LB,
        "label": "Live Leaderboards",
        "title": "Live leaderboards",
        "description": None,
        "commands": [
            (",createlivelb", "Create a live leaderboard of invites, messages, voice updated every 30 seconds"),
            (",deletelivelb", "Delete a live leaderboard"),
            (",showlivelbs", "Shows the live leaderboards information of your server"),
        ],
    },
    "giveaway": {
        "emoji": E_GW,
        "label": "Giveaways",
        "title": "Giveaway",
        "description": "Create giveaways",
        "commands_with_header": True,
        "commands": [
            (",gcreate", "Create giveaways with requirements"),
            (",gstart", "Creates a giveaway"),
            (",greroll", "Rerolls an ended giveaway"),
            (",gend", "Ends an active giveaway"),
            (",setgiveaway", "customize giveaway embed"),
            (",unsetgiveaway", "Disable premium giveaway features"),
            (",viewwinnerrole", "Shows your custom giveaway winner role"),
            (",viewbypassrole", "Shows your custom giveaway bypass role"),
        ],
    },
    "timer": {
        "emoji": E_TIMER,
        "label": "Timer",
        "title": "Timer",
        "description": None,
        "commands": [
            (",tstart <time> [label]", "Start a timer (30s, 5m, 3h, 1d)"),
            (",tpause", "Pause the active timer"),
            (",tresume", "Resume a paused timer"),
            (",tend", "End the active timer early"),
        ],
    },
    "greet": {
        "emoji": E_GREET,
        "label": "Greet",
        "title": "Set greet message",
        "description": "Welcome new users in up to 3 channels",
        "commands_with_header": True,
        "commands": [
            (",setgreet", "Greet configuration commands"),
            (",setgreet embed", "Sets a greet to welcome new members"),
            (",setgreet message", "Sets a greet to welcome new members"),
            (",disablegreet", "Disables the greet welcome system of a channel"),
            (",greetchannels", "Displays the total channels set for greet welcome system"),
            (",greetvariables", "Displays the variables that you can use them in greet welcome message"),
        ],
    },
    "moderation": {
        "emoji": E_MOD,
        "label": "Moderation",
        "title": "Moderation",
        "description": None,
        "commands": [
            (",kick", "Kicks a user from a guild"),
            (",erase", "Delete a number of messages from a channel"),
            (",ban", "Bans a user from a guild"),
            (",unban", "Unbans a banned user from a Discord server"),
            (",mute", "Mutes a server member for a specified amount of time"),
            (",unmute", "Unmutes a server member"),
        ],
    },
    "managecommands": {
        "emoji": E_MANAGE,
        "label": "Manage Commands",
        "title": "Manage Commands",
        "description": None,
        "commands": [
            (",disable command", "Disables a specific command"),
            (",disable module", "Disable a module in a channel or in the server"),
            (",enable module", "Remove module from the blacklist"),
            (",enable command", "Remove command from the blacklist"),
        ],
    },
    "poll": {
        "emoji": E_POLL,
        "label": "Poll",
        "title": "Polls",
        "description": "Creates a poll",
        "commands_with_header": True,
        "commands": [
            (",createpoll", "Create a poll"),
            (",epoll", "Ends an active poll"),
        ],
    },
    "utility": {
        "emoji": E_UTILITY,
        "label": "Utility",
        "title": "Utility",
        "description": None,
        "commands": [
            (",ping", "Check bot latency"),
            (",serverinfo", "Displays server information"),
            (",userinfo", "Displays user information"),
            (",avatar", "Displays a user's avatar"),
        ],
    },
    "credits": {
        "emoji": E_CONTACT,
        "label": "Credits",
        "title": "Credits",
        "description": None,
        "contact": True,
    },
}


def build_main_help_embed(custom_emojis=None):
    keys = list(HELP_SECTIONS.keys())

    def em(i):
        if custom_emojis and i < len(custom_emojis) and custom_emojis[i]:
            return custom_emojis[i]
        return HELP_SECTIONS[keys[i]]["emoji"]

    embed = discord.Embed(color=COLOR)
    embed.description = (
        f"Hey there, my prefix is `,`\n\n"
        f"{E_NEWS} **News:**\n"
        f"> {ARROW} Access the new Falcon Premium Dashboard to configure your server!\n"
        f"> {ARROW} Upgrade your Discord server with Falcon Premium now to enjoy feature rich Discord bot!\n\n"
        f"I can do invite tracking, message tracking, voice state tracking, can manage your server events with giveaways, greet system ,timers, polls and much more! "
        f"You can checkout my other commands in the context menu!\n\n"
        f"{em(0)} • **Premium utility**\n"
        f"{em(1)} • **Invite tracking**\n"
        f"{em(2)} • **Messages**\n"
        f"{em(3)} • **Voice**\n"
        f"{em(4)} • **Auto Roles**\n"
        f"{em(5)} • **Live Leaderboards**\n"
        f"{em(6)} • **Giveaways**\n"
        f"{em(7)} • **Timer**\n"
        f"{em(8)} • **Greet**\n"
        f"{em(9)} • **Moderation**\n"
        f"{em(10)} • **Manage Commands**\n"
        f"{em(11)} • **Poll**\n"
        f"{em(12)} • **Utility**\n"
        f"{em(13)} • **Credits**"
    )
    return embed


def build_section_embed(section_key: str):
    s = HELP_SECTIONS[section_key]
    embed = discord.Embed(color=COLOR)
    embed.title = s["title"]

    if s.get("contact"):
        embed.description = (
            f"{ARROW} **Support server:** [Join here]({SUPPORT_SERVER_URL})\n"
            f"{ARROW} **Owner:** <@{PRIMARY_OWNER_ID}>\n"
            f"{ARROW} **Owner ID:** `{PRIMARY_OWNER_ID}`"
        )
        return embed

    if s.get("description"):
        embed.description = s["description"] + "\n"
    else:
        embed.description = ""

    has_header = s.get("commands_with_header", False)
    if has_header:
        embed.description += "\n**Commands**"

    lines = []
    for item in s["commands"]:
        if isinstance(item, tuple):
            cmd, desc = item
        else:
            cmd, desc = item, None
        if desc:
            lines.append(f"{ARROW} `{cmd}` - {desc}")
        else:
            lines.append(f"{ARROW} `{cmd}`")

    embed.description += "\n" + "\n".join(lines)
    return embed


HELP_DROPDOWN_META = {
    "main": ("Index", "The help page showing how to use the bot"),
    "premium": ("Premium", "Shows the information about premium utility commands"),
    "invites": ("Invite logging", "Shows the information about invite tracking feature"),
    "messages": ("Messages", "Shows the information about message counting feature"),
    "voice": ("Voice", "Shows the information about voice stats feature"),
    "autoroles": ("Auto Roles", "Shows the information about Auto role feature"),
    "liveleaderboards": ("Live leaderboard", "Shows the information about live self refreshing leaderboards feature"),
    "giveaway": ("Giveaways", "Shows the information about giveaway feature"),
    "timer": ("Timer", "Shows you the information about event timer feature"),
    "greet": ("Greet", "Shows you the information about greet welcome feature"),
    "moderation": ("Moderation", "Shows you the information about moderation features"),
    "managecommands": ("Manage Commands", "Enable/Disable commands in your server"),
    "poll": ("Polls", "Shows you the information about the polls feature"),
    "utility": ("Utilities", "Shows you the information about utility features"),
    "credits": ("Contact", "Contact us if you need support"),
}


class HelpDropdown(discord.ui.Select):
    def __init__(self, bot, custom_emojis=None):
        self.bot = bot
        options = [
            discord.SelectOption(
                label=HELP_DROPDOWN_META["main"][0],
                value="main",
                description=HELP_DROPDOWN_META["main"][1],
                emoji="\U0001F3E0",
            ),
        ]
        keys = list(HELP_SECTIONS.keys())
        for i, key in enumerate(keys):
            data = HELP_SECTIONS[key]
            emoji_str = data["emoji"]
            if custom_emojis and i < len(custom_emojis) and custom_emojis[i]:
                emoji_str = custom_emojis[i]
            emoji_obj = None
            try:
                emoji_obj = discord.PartialEmoji.from_str(emoji_str)
            except Exception:
                emoji_obj = None
            try:
                options.append(
                    discord.SelectOption(
                        label=HELP_DROPDOWN_META.get(key, (data["label"], None))[0],
                        value=key,
                        description=HELP_DROPDOWN_META.get(key, (None, None))[1],
                        emoji=emoji_obj or emoji_str,
                    )
                )
            except Exception:
                options.append(
                    discord.SelectOption(
                        label=HELP_DROPDOWN_META.get(key, (data["label"], None))[0],
                        value=key,
                        description=HELP_DROPDOWN_META.get(key, (None, None))[1],
                    )
                )
        super().__init__(placeholder="Select a category...", min_values=1, max_values=1, options=options)

    async def callback(self, interaction: discord.Interaction):
        val = self.values[0]
        gid = interaction.guild.id if interaction.guild else None
        custom = await get_guild_dropdown_emojis(self.bot, gid)
        if val == "main":
            embed = build_main_help_embed(custom_emojis=custom)
        else:
            embed = build_section_embed(val)
        for opt in self.options:
            opt.default = opt.value == val
        await interaction.response.edit_message(embed=embed, view=self.view)


class HelpView(discord.ui.View):
    def __init__(self, bot, custom_emojis=None):
        super().__init__(timeout=120)
        self.add_item(HelpDropdown(bot, custom_emojis=custom_emojis))
        self.add_item(discord.ui.Button(label="Go to Dashboard", url=DASHBOARD_URL, style=discord.ButtonStyle.url))
        self.add_item(discord.ui.Button(label="Terms of service", url=TOS_URL, style=discord.ButtonStyle.url))
        self.add_item(discord.ui.Button(label="Privacy Policy", url=PRIVACY_URL, style=discord.ButtonStyle.url))
        self.add_item(
            discord.ui.Button(
                label="Invite me",
                url=f"https://discord.com/oauth2/authorize?client_id={CLIENT_ID}&permissions=8&integration_type=0&scope=bot",
                style=discord.ButtonStyle.url,
            )
        )
        self.add_item(discord.ui.Button(label="Support server", url=SUPPORT_SERVER_URL, style=discord.ButtonStyle.url))
        self.add_item(discord.ui.Button(label="Vote me", url=VOTE_URL, style=discord.ButtonStyle.url))


class Help(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="help")
    async def help_cmd(self, ctx):
        custom = await get_guild_dropdown_emojis(self.bot, ctx.guild.id if ctx.guild else None)
        embed = build_main_help_embed(custom_emojis=custom)
        view = HelpView(self.bot, custom_emojis=custom)
        await ctx.send(embed=embed, view=view)

    @commands.command(name="credits")
    async def credits_cmd(self, ctx):
        custom = await get_guild_dropdown_emojis(self.bot, ctx.guild.id if ctx.guild else None)
        embed = build_section_embed("credits")
        view = HelpView(self.bot, custom_emojis=custom)
        for opt in view.children[0].options:
            opt.default = opt.value == "credits"
        await ctx.send(embed=embed, view=view)

    @commands.hybrid_command(name="refreshemojis", description="(Owner) Use this server's emojis in the help dropdown")
    async def refresh_emojis(self, ctx):
        if not await is_bot_owner(self.bot, ctx.author.id):
            return
        if not ctx.guild:
            return await ctx.send(f"{DOT} Run this inside a server.")
        ok = await store_guild_dropdown_emojis(self.bot, ctx.guild)
        if ok:
            await ctx.send(
                f"{DOT} Dropdown emojis updated using **{ctx.guild.name}**'s emojis. Try `,help`."
            )
        else:
            await ctx.send(f"{DOT} This server has no custom emojis to use.")

    @commands.hybrid_command(name="resetemojis", description="(Owner) Reset help dropdown emojis to defaults")
    async def reset_emojis(self, ctx):
        if not await is_bot_owner(self.bot, ctx.author.id):
            return
        if not ctx.guild:
            return
        await self.bot.db.execute("DELETE FROM guild_help_emojis WHERE guild_id = ?", (ctx.guild.id,))
        await self.bot.db.commit()
        await ctx.send(f"{DOT} Dropdown emojis reset to defaults.")


async def setup(bot):
    await bot.add_cog(Help(bot))
