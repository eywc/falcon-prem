"""
Greet / welcome channel configuration commands.
Join/leave message sending lives in events.py.
"""
import discord
from discord.ext import commands

from config import COLOR
from utils.emojis import DOT


class Greet(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="setgreet")
    @commands.has_permissions(manage_guild=True)
    async def setgreet(self, ctx, mode: str = "embed", channel: discord.TextChannel = None):
        channel = channel or ctx.channel
        async with self.bot.db.execute(
            "SELECT COUNT(*) FROM greet_channels WHERE guild_id=?", (ctx.guild.id,)
        ) as cur:
            count = (await cur.fetchone())[0]
        if count >= 3:
            return await ctx.send(f"❌ You can only have up to **3** greet channels.")
        if mode not in ("embed", "message"):
            return await ctx.send("❌ Mode must be `embed` or `message`.")
        await self.bot.db.execute(
            "INSERT OR REPLACE INTO greet_channels (guild_id, channel_id, greet_type) VALUES (?, ?, ?)",
            (ctx.guild.id, channel.id, mode),
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR,
            description=f"{DOT} Greet channel set to {channel.mention} (`{mode}` mode).",
        )
        await ctx.send(embed=embed)

    @commands.command(name="disablegreet")
    @commands.has_permissions(manage_guild=True)
    async def disablegreet(self, ctx, channel: discord.TextChannel = None):
        channel = channel or ctx.channel
        await self.bot.db.execute(
            "DELETE FROM greet_channels WHERE guild_id=? AND channel_id=?",
            (ctx.guild.id, channel.id),
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} Greet system disabled for {channel.mention}."
        )
        await ctx.send(embed=embed)

    @commands.command(name="greetchannels")
    async def greetchannels(self, ctx):
        async with self.bot.db.execute(
            "SELECT channel_id, greet_type FROM greet_channels WHERE guild_id=?", (ctx.guild.id,)
        ) as cur:
            rows = await cur.fetchall()
        embed = discord.Embed(color=COLOR, title="👋 Greet Channels")
        embed.description = (
            "\n".join([f"{DOT} <#{r[0]}> — `{r[1]}` mode" for r in rows])
            if rows
            else f"{DOT} No greet channels configured."
        )
        await ctx.send(embed=embed)

    @commands.command(name="greetvariables")
    async def greetvariables(self, ctx):
        embed = discord.Embed(color=COLOR, title="📋 Greet Variables")
        embed.description = (
            f"{DOT} `{{user}}` — Mentions the user\n"
            f"{DOT} `{{username}}` — User's name\n"
            f"{DOT} `{{server}}` — Server name\n"
            f"{DOT} `{{membercount}}` — Total members\n"
        )
        await ctx.send(embed=embed)

    # Channel / message setters that were in the original invite section
    @commands.command(name="setjoinchannel")
    @commands.has_permissions(manage_guild=True)
    async def setjoinchannel(self, ctx, channel: discord.TextChannel = None):
        channel = channel or ctx.channel
        await self.bot.db.execute(
            "INSERT INTO guild_settings (guild_id, join_channel_id) VALUES (?, ?) "
            "ON CONFLICT(guild_id) DO UPDATE SET join_channel_id=excluded.join_channel_id",
            (ctx.guild.id, channel.id),
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} Welcome channel set to {channel.mention}."
        )
        await ctx.send(embed=embed)

    @commands.command(name="unsetwelcomechannel")
    @commands.has_permissions(manage_guild=True)
    async def unsetwelcomechannel(self, ctx):
        await self.bot.db.execute(
            "UPDATE guild_settings SET join_channel_id=NULL WHERE guild_id=?", (ctx.guild.id,)
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR,
            description=f"{DOT} Welcome channel unset. Join messages are now **disabled**.",
        )
        await ctx.send(embed=embed)

    @commands.command(name="setleave")
    @commands.has_permissions(manage_guild=True)
    async def setleave(self, ctx, channel: discord.TextChannel = None):
        channel = channel or ctx.channel
        await self.bot.db.execute(
            "INSERT INTO guild_settings (guild_id, leave_channel_id) VALUES (?, ?) "
            "ON CONFLICT(guild_id) DO UPDATE SET leave_channel_id=excluded.leave_channel_id",
            (ctx.guild.id, channel.id),
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} Leave channel set to {channel.mention}."
        )
        await ctx.send(embed=embed)

    @commands.command(name="unsetleavechannel")
    @commands.has_permissions(manage_guild=True)
    async def unsetleavechannel(self, ctx):
        await self.bot.db.execute(
            "UPDATE guild_settings SET leave_channel_id=NULL WHERE guild_id=?", (ctx.guild.id,)
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR,
            description=f"{DOT} Leave channel unset. Leave messages are now **disabled**.",
        )
        await ctx.send(embed=embed)

    @commands.command(name="setjoinmessage")
    @commands.has_permissions(manage_guild=True)
    async def setjoinmessage(self, ctx, *, message: str):
        await self.bot.db.execute(
            "INSERT INTO guild_settings (guild_id, join_message) VALUES (?, ?) "
            "ON CONFLICT(guild_id) DO UPDATE SET join_message=excluded.join_message",
            (ctx.guild.id, message),
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} Custom join message set!\n\n**Preview:**\n{message}"
        )
        await ctx.send(embed=embed)

    @commands.command(name="unsetjoinmessage")
    @commands.has_permissions(manage_guild=True)
    async def unsetjoinmessage(self, ctx):
        await self.bot.db.execute(
            "UPDATE guild_settings SET join_message=NULL WHERE guild_id=?", (ctx.guild.id,)
        )
        await self.bot.db.commit()
        embed = discord.Embed(color=COLOR, description=f"{DOT} Custom join message deleted.")
        await ctx.send(embed=embed)

    @commands.command(name="setleavemessage")
    @commands.has_permissions(manage_guild=True)
    async def setleavemessage(self, ctx, *, message: str):
        await self.bot.db.execute(
            "INSERT INTO guild_settings (guild_id, leave_message) VALUES (?, ?) "
            "ON CONFLICT(guild_id) DO UPDATE SET leave_message=excluded.leave_message",
            (ctx.guild.id, message),
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} Custom leave message set!\n\n**Preview:**\n{message}"
        )
        await ctx.send(embed=embed)

    @commands.command(name="unsetleavemessage")
    @commands.has_permissions(manage_guild=True)
    async def unsetleavemessage(self, ctx):
        await self.bot.db.execute(
            "UPDATE guild_settings SET leave_message=NULL WHERE guild_id=?", (ctx.guild.id,)
        )
        await self.bot.db.commit()
        embed = discord.Embed(color=COLOR, description=f"{DOT} Custom leave message deleted.")
        await ctx.send(embed=embed)

    @commands.command(name="setvanitymessage")
    @commands.has_permissions(manage_guild=True)
    async def setvanitymessage(self, ctx, *, message: str):
        await self.bot.db.execute(
            "INSERT INTO guild_settings (guild_id, vanity_message) VALUES (?, ?) "
            "ON CONFLICT(guild_id) DO UPDATE SET vanity_message=excluded.vanity_message",
            (ctx.guild.id, message),
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} Custom vanity message set!\n\n**Preview:**\n{message}"
        )
        await ctx.send(embed=embed)

    @commands.command(name="unsetvanitymessage")
    @commands.has_permissions(manage_guild=True)
    async def unsetvanitymessage(self, ctx):
        await self.bot.db.execute(
            "UPDATE guild_settings SET vanity_message=NULL WHERE guild_id=?", (ctx.guild.id,)
        )
        await self.bot.db.commit()
        embed = discord.Embed(color=COLOR, description=f"{DOT} Custom vanity message deleted.")
        await ctx.send(embed=embed)

    @commands.command(name="variables")
    async def variables(self, ctx):
        embed = discord.Embed(color=COLOR, title="📋 Message Variables")
        embed.description = (
            f"{DOT} `{{user}}` — Mentions the user\n"
            f"{DOT} `{{username}}` — User's name\n"
            f"{DOT} `{{server}}` — Server name\n"
            f"{DOT} `{{membercount}}` — Total member count\n"
            f"{DOT} `{{inviter}}` — Who invited the user\n"
        )
        await ctx.send(embed=embed)

    @commands.command(name="testmsg")
    @commands.has_permissions(manage_guild=True)
    async def testmsg(self, ctx, *, message: str):
        text = (
            message.replace("{user}", ctx.author.mention)
            .replace("{username}", ctx.author.name)
            .replace("{server}", ctx.guild.name)
            .replace("{membercount}", str(ctx.guild.member_count))
            .replace("{inviter}", ctx.author.mention)
        )
        embed = discord.Embed(color=COLOR, title="🧪 Message Preview")
        embed.description = text
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Greet(bot))
