"""
Premium-related commands.
"""
from datetime import datetime, timedelta

import discord
from discord.ext import commands

from config import COLOR
from utils.emojis import DOT, ARROW
from utils.checks import is_bot_owner


class Premium(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="premium")
    async def premium_cmd(self, ctx, action: str = None, *, target: str = None):
        embed = discord.Embed(
            color=COLOR, title="Premium", description="Displays premium command usage\n\n**Commands**"
        )
        embed.description += (
            f"\n{ARROW} `,premium activate`"
            f"\n{ARROW} `,premium gift`"
            f"\n{ARROW} `,premium view user`"
            f"\n{ARROW} `,premium view guild`"
        )
        if action == "activate":
            embed = discord.Embed(
                color=COLOR,
                description=f"{DOT} To activate premium, please visit our dashboard or support server.",
            )
        elif action == "gift":
            embed = discord.Embed(
                color=COLOR, description=f"{DOT} Use `,premium gift @user` to gift premium."
            )
        elif action == "view":
            if target == "user":
                async with self.bot.db.execute(
                    "SELECT expiry FROM premium_users WHERE user_id=?", (ctx.author.id,)
                ) as cur:
                    row = await cur.fetchone()
                if row:
                    embed = discord.Embed(
                        color=COLOR, description=f"{DOT} You have premium until `{row[0][:10]}`."
                    )
                else:
                    embed = discord.Embed(
                        color=COLOR, description=f"{DOT} You do not have a premium subscription."
                    )
            elif target == "guild":
                async with self.bot.db.execute(
                    "SELECT expiry FROM premium_guilds WHERE guild_id=?", (ctx.guild.id,)
                ) as cur:
                    row = await cur.fetchone()
                if row:
                    embed = discord.Embed(
                        color=COLOR,
                        description=f"{DOT} This guild has premium until `{row[0][:10]}`.",
                    )
                else:
                    embed = discord.Embed(
                        color=COLOR, description=f"{DOT} This guild does not have premium."
                    )
        await ctx.send(embed=embed)

    @commands.command(name="premiumadd", aliases=["padd"])
    async def premium_add_cmd(self, ctx, user: discord.Member = None, days: int = 30):
        if not await is_bot_owner(self.bot, ctx.author.id):
            return
        if not user:
            return await ctx.send(f"{DOT} Usage: `,premiumadd @user [days=30]`")
        expiry = datetime.now() + timedelta(days=days)
        await self.bot.db.execute(
            "INSERT OR REPLACE INTO premium_users (user_id, expiry) VALUES (?, ?)",
            (user.id, expiry.isoformat()),
        )
        await self.bot.db.commit()
        await ctx.send(
            embed=discord.Embed(
                color=COLOR,
                description=(
                    f"{DOT} {user.mention} now has **Premium** for **{days} days** "
                    f"(until <t:{int(expiry.timestamp())}:F>)."
                ),
            )
        )

    @commands.command(name="premiumremove", aliases=["premrm"])
    async def premium_remove_cmd(self, ctx, user: discord.Member = None):
        if not await is_bot_owner(self.bot, ctx.author.id):
            return
        if not user:
            return await ctx.send(f"{DOT} Usage: `,premiumremove @user`")
        await self.bot.db.execute("DELETE FROM premium_users WHERE user_id = ?", (user.id,))
        await self.bot.db.commit()
        await ctx.send(
            embed=discord.Embed(
                color=COLOR, description=f"{DOT} Removed Premium from {user.mention}."
            )
        )


async def setup(bot):
    await bot.add_cog(Premium(bot))
