"""
Timer commands: tstart, tpause, tresume, tend.
"""
import asyncio
from datetime import datetime, timedelta

import discord
from discord.ext import commands

from config import COLOR
from utils.emojis import DOT
from utils.helpers import parse_duration

active_timers = {}


async def run_timer(bot, guild_id: int, seconds: int):
    try:
        await asyncio.sleep(seconds)
        data = active_timers.get(guild_id)
        if not data:
            return
        channel = bot.get_channel(data["channel_id"])
        label = data.get("label", "Timer")
        if channel:
            embed = discord.Embed(color=COLOR, description=f"{DOT} ⏰ **{label}** has ended!")
            await channel.send(embed=embed)
        active_timers.pop(guild_id, None)
    except asyncio.CancelledError:
        pass


class Timer(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="tstart")
    @commands.has_permissions(manage_guild=True)
    async def tstart(self, ctx, time_str: str, *, label: str = "Timer"):
        if ctx.guild.id in active_timers:
            return await ctx.send(f"❌ A timer is already running! Use `,tend` to end it first.")
        seconds = parse_duration(time_str)
        if not seconds:
            return await ctx.send(f"❌ Invalid format. Use `30s`, `5m`, `3h`, `1d`.")
        end_time = datetime.now() + timedelta(seconds=seconds)
        task = self.bot.loop.create_task(run_timer(self.bot, ctx.guild.id, seconds))
        active_timers[ctx.guild.id] = {
            "task": task,
            "end_time": end_time,
            "paused": False,
            "remaining": seconds,
            "channel_id": ctx.channel.id,
            "label": label,
        }
        embed = discord.Embed(color=COLOR)
        embed.set_author(name="⏱️ Timer Started")
        embed.description = (
            f"{DOT} **Label:** {label}\n"
            f"{DOT} **Duration:** `{time_str}`\n"
            f"{DOT} **Ends:** <t:{int(end_time.timestamp())}:R> ( <t:{int(end_time.timestamp())}:F> )"
        )
        await ctx.send(embed=embed)

    @commands.command(name="tpause")
    @commands.has_permissions(manage_guild=True)
    async def tpause(self, ctx):
        data = active_timers.get(ctx.guild.id)
        if not data:
            return await ctx.send(f"❌ No active timer to pause.")
        if data["paused"]:
            return await ctx.send(f"❌ Timer is already paused.")
        remaining = int((data["end_time"] - datetime.now()).total_seconds())
        if remaining <= 0:
            return await ctx.send(f"❌ Timer has already ended.")
        data["task"].cancel()
        data["paused"] = True
        data["remaining"] = remaining
        embed = discord.Embed(color=COLOR)
        embed.set_author(name="⏸️ Timer Paused")
        embed.description = f"{DOT} **{data['label']}** paused with **{remaining}s** remaining."
        await ctx.send(embed=embed)

    @commands.command(name="tresume")
    @commands.has_permissions(manage_guild=True)
    async def tresume(self, ctx):
        data = active_timers.get(ctx.guild.id)
        if not data:
            return await ctx.send(f"❌ No timer found.")
        if not data["paused"]:
            return await ctx.send(f"❌ Timer is not paused.")
        remaining = data["remaining"]
        new_end = datetime.now() + timedelta(seconds=remaining)
        task = self.bot.loop.create_task(run_timer(self.bot, ctx.guild.id, remaining))
        data["task"] = task
        data["end_time"] = new_end
        data["paused"] = False
        embed = discord.Embed(color=COLOR)
        embed.set_author(name="▶️ Timer Resumed")
        embed.description = (
            f"{DOT} **{data['label']}** resumed!\n"
            f"{DOT} **Ends:** <t:{int(new_end.timestamp())}:R>"
        )
        await ctx.send(embed=embed)

    @commands.command(name="tend")
    @commands.has_permissions(manage_guild=True)
    async def tend(self, ctx):
        data = active_timers.pop(ctx.guild.id, None)
        if not data:
            return await ctx.send(f"❌ No active timer to end.")
        data["task"].cancel()
        embed = discord.Embed(color=COLOR)
        embed.set_author(name="⏹️ Timer Ended")
        embed.description = f"{DOT} **{data['label']}** has been ended early."
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Timer(bot))
