"""
Voice tracking commands and on_voice_state_update listener.
"""
from datetime import datetime

import discord
from discord.ext import commands

from config import COLOR
from utils.emojis import DOT
from utils.database import update_user, get_user_data
from utils.helpers import format_seconds

voice_join_times = {}


class Voice(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        if member.bot:
            return
        uid = member.id
        if before.channel is None and after.channel is not None:
            voice_join_times[uid] = datetime.now()
        elif before.channel is not None and after.channel is None:
            if uid in voice_join_times:
                duration = int((datetime.now() - voice_join_times.pop(uid)).total_seconds())
                await update_user(
                    self.bot, uid, voice_alltime=duration, voice_weekly=duration, voice_daily=duration
                )

    @commands.command(name="vc")
    async def vc_cmd(self, ctx, user: discord.Member = None):
        user = user or ctx.author
        _, _, _, _, _, _, alltime, weekly, daily = await get_user_data(self.bot, user.id)
        embed = discord.Embed(color=COLOR, title=f"{user.name}'s Voice Stats")
        embed.description = (
            f"**All time • {format_seconds(alltime)}**\n"
            f"**Weekly • {format_seconds(weekly)}**\n"
            f"**Daily • {format_seconds(daily)}**\n\n"
            f"*Updated in real-time*"
        )
        await ctx.send(embed=embed)

    @commands.command(name="addvctime")
    @commands.has_permissions(administrator=True)
    async def addvctime(self, ctx, user: discord.Member, amount: int):
        """Add voice time in seconds to a user's all time, daily and weekly fields."""
        await update_user(
            self.bot, user.id, voice_alltime=amount, voice_weekly=amount, voice_daily=amount
        )
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} Added **{amount}s** of voice time to {user.mention}."
        )
        await ctx.send(embed=embed)

    @commands.command(name="reducevctime")
    @commands.has_permissions(administrator=True)
    async def reducevctime(self, ctx, user: discord.Member, amount: int):
        """Reduce voice time from all time, daily and weekly fields."""
        await update_user(
            self.bot, user.id, voice_alltime=-amount, voice_weekly=-amount, voice_daily=-amount
        )
        embed = discord.Embed(
            color=COLOR,
            description=f"{DOT} Reduced **{amount}s** of voice time from {user.mention}.",
        )
        await ctx.send(embed=embed)

    @commands.command(name="clearvoice")
    @commands.has_permissions(administrator=True)
    async def clearvoice(self, ctx, user: discord.Member = None):
        if user:
            await self.bot.db.execute(
                "UPDATE users SET voice_alltime=0, voice_weekly=0, voice_daily=0 WHERE user_id=?",
                (user.id,),
            )
            embed = discord.Embed(
                color=COLOR, description=f"{DOT} Cleared voice stats for {user.mention}."
            )
        else:
            await self.bot.db.execute(
                "UPDATE users SET voice_alltime=0, voice_weekly=0, voice_daily=0"
            )
            embed = discord.Embed(
                color=COLOR,
                description=f"{DOT} Cleared **all** members' voice stats in this guild.",
            )
        await self.bot.db.commit()
        await ctx.send(embed=embed)

    @commands.command(name="resetmyvoice")
    async def resetmyvoice(self, ctx):
        await self.bot.db.execute(
            "UPDATE users SET voice_alltime=0, voice_weekly=0, voice_daily=0 WHERE user_id=?",
            (ctx.author.id,),
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR,
            description=f"{DOT} Your voice stats have been reset, {ctx.author.mention}.",
        )
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Voice(bot))
