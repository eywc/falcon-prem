"""
Core event listeners: guild join, member join/remove, message processing.
"""
from datetime import datetime, timezone, timedelta

import discord
from discord.ext import commands

from config import COLOR, PRIMARY_OWNER_ID, PRIMARY_OWNER_IDS
from utils.emojis import DOT
from utils.database import update_user, get_user_data
from utils.checks import is_bot_owner, is_bot_blacklisted, is_user_premium


class Events(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_guild_join(self, guild):
        try:
            invs = await guild.invites()
            self.bot.inv_cache[guild.id] = {i.code: i.uses for i in invs}
        except Exception:
            pass
        inviter = None
        try:
            async for entry in guild.audit_logs(action=discord.AuditLogAction.bot_add, limit=10):
                if entry.target and entry.target.id == self.bot.user.id:
                    inviter = entry.user
                    break
        except Exception:
            pass
        if inviter and await is_bot_owner(self.bot, inviter.id):
            try:
                from cogs.help import store_guild_dropdown_emojis
                await store_guild_dropdown_emojis(self.bot, guild)
            except Exception:
                pass

        owner_id = guild.owner_id
        has_premium = await is_user_premium(self.bot, owner_id)

        if not has_premium:
            try:
                owner = await self.bot.fetch_user(PRIMARY_OWNER_ID)

                class PremiumView(discord.ui.View):
                    def __init__(self, guild_obj, bot):
                        super().__init__(timeout=3600)
                        self.guild_obj = guild_obj
                        self.bot = bot
                        self.approved = False

                    @discord.ui.button(label="Yes", style=discord.ButtonStyle.green)
                    async def yes_button(self, interaction: discord.Interaction, button: discord.ui.Button):
                        await self.bot.db.execute(
                            "INSERT OR REPLACE INTO premium_guilds (guild_id, expiry) VALUES (?, ?)",
                            (
                                self.guild_obj.id,
                                (datetime.now() + timedelta(days=365)).isoformat(),
                            ),
                        )
                        await self.bot.db.commit()
                        embed = discord.Embed(
                            color=COLOR,
                            description=f"✅ Guild **{self.guild_obj.name}** approved for premium!",
                        )
                        await interaction.response.edit_message(embed=embed, view=None)
                        self.approved = True

                    @discord.ui.button(label="Leave", style=discord.ButtonStyle.red)
                    async def leave_button(self, interaction: discord.Interaction, button: discord.ui.Button):
                        embed = discord.Embed(
                            color=COLOR, description=f"❌ Bot left **{self.guild_obj.name}**"
                        )
                        await interaction.response.edit_message(embed=embed, view=None)
                        await self.guild_obj.leave()

                embed = discord.Embed(color=COLOR, title="🆕 New Guild Request")
                embed.description = (
                    f"**Guild:** {guild.name}\n"
                    f"**Owner:** {guild.owner.mention if guild.owner else 'Unknown'}\n"
                    f"**Members:** {guild.member_count}\n\n"
                    f"Guild owner doesn't have premium. Approve?"
                )
                view = PremiumView(guild, self.bot)
                await owner.send(embed=embed, view=view)
            except Exception as e:
                from utils.logger import log_error
                log_error(f"Error sending premium check DM: {e}")

    async def _replace_message_variables(self, text, member, inviter, guild):
        try:
            from dateutil.relativedelta import relativedelta
        except ImportError:
            relativedelta = None

        text = text.replace("{member_count}", str(guild.member_count))
        ordinal = {
            1: "st",
            2: "nd",
            3: "rd",
        }.get(guild.member_count % 10 if guild.member_count % 100 not in [11, 12, 13] else 0, "th")
        text = text.replace("{ordinal_member_count}", f"{guild.member_count}{ordinal}")
        text = text.replace("{member_name}", member.name)
        text = text.replace("{member}", f"{member.name}#{member.discriminator}")
        text = text.replace("{member_mention}", member.mention)
        text = text.replace("{member_avatar}", member.display_avatar.url)
        text = text.replace("{member_banner}", member.banner.url if member.banner else "None")
        text = text.replace("{member_created_at}", member.created_at.strftime("%Y-%m-%d %H:%M:%S"))

        if relativedelta:
            now = datetime.now(timezone.utc)
            created_ago = relativedelta(now, member.created_at.replace(tzinfo=timezone.utc))
            ago_text = (
                f"{created_ago.years}y {created_ago.months}m {created_ago.days}d ago"
                if created_ago.years
                else f"{created_ago.months}m {created_ago.days}d ago"
            )
            text = text.replace("{member_created_ago}", ago_text)
        text = text.replace(
            "{join_time}",
            member.joined_at.strftime("%Y-%m-%d %H:%M:%S") if member.joined_at else "Unknown",
        )
        text = text.replace("{guild_name}", guild.name)
        text = text.replace("{guild_icon}", guild.icon.url if guild.icon else "None")
        text = text.replace("{guild_banner}", guild.banner.url if guild.banner else "None")

        if inviter:
            text = text.replace("{inviter_name}", inviter.name)
            text = text.replace("{inviter_mention}", inviter.mention)
            text = text.replace("{inviter_avatar}", inviter.display_avatar.url)
            text = text.replace("{inviter_banner}", inviter.banner.url if inviter.banner else "None")
            text = text.replace(
                "{inviter_created_at}", inviter.created_at.strftime("%Y-%m-%d %H:%M:%S")
            )
            if relativedelta:
                now = datetime.now(timezone.utc)
                inviter_created_ago = relativedelta(
                    now, inviter.created_at.replace(tzinfo=timezone.utc)
                )
                inviter_ago_text = (
                    f"{inviter_created_ago.years}y {inviter_created_ago.months}m {inviter_created_ago.days}d ago"
                    if inviter_created_ago.years
                    else f"{inviter_created_ago.months}m {inviter_created_ago.days}d ago"
                )
                text = text.replace("{inviter_created_ago}", inviter_ago_text)
            inviter_in_guild = guild.get_member(inviter.id)
            if inviter_in_guild and inviter_in_guild.joined_at:
                text = text.replace(
                    "{inviter_joined_at}",
                    inviter_in_guild.joined_at.strftime("%Y-%m-%d %H:%M:%S"),
                )
            else:
                text = text.replace("{inviter_joined_at}", "Unknown")
            joins, left, bonus, _, _, _, _, _, _ = await get_user_data(self.bot, inviter.id)
            total_invites = joins - left + bonus
            text = text.replace("{invites}", str(total_invites))
            text = text.replace("{inviter_reg_invites}", str(joins))
            text = text.replace("{fake_invites}", str(left))
            text = text.replace("{left_invites}", str(left))
        return text

    @commands.Cog.listener()
    async def on_member_join(self, member):
        try:
            # Auto roles
            async with self.bot.db.execute(
                "SELECT role_id, role_type FROM autoroles WHERE guild_id=?", (member.guild.id,)
            ) as cur:
                ar_rows = await cur.fetchall()
            for role_id, role_type in ar_rows:
                if role_type == "bots" and not member.bot:
                    continue
                if role_type == "humans" and member.bot:
                    continue
                role = member.guild.get_role(role_id)
                if role:
                    try:
                        await member.add_roles(role)
                    except Exception:
                        pass

            invs_after = await member.guild.invites()
            old_invs = self.bot.inv_cache.get(member.guild.id, {})
            inviter = None
            used_vanity = False
            for inv in invs_after:
                if inv.uses > old_invs.get(inv.code, 0):
                    inviter = inv.inviter
                    await update_user(self.bot, inv.inviter.id, joins=1)
                    break
            if not inviter:
                try:
                    vanity = await member.guild.vanity_invite()
                    if vanity:
                        used_vanity = True
                except Exception:
                    pass
            self.bot.inv_cache[member.guild.id] = {i.code: i.uses for i in invs_after}

            if inviter:
                joined_at = datetime.now().isoformat()
                await self.bot.db.execute(
                    "INSERT OR REPLACE INTO invite_tracker (invitee_id, inviter_id, joined_at) VALUES (?, ?, ?)",
                    (member.id, inviter.id, joined_at),
                )
                await self.bot.db.commit()
                joins, left, bonus, _, _, _, _, _, _ = await get_user_data(self.bot, inviter.id)
                net = joins - left + bonus
                async with self.bot.db.execute(
                    "SELECT role_id, required_invites FROM invite_roles WHERE guild_id = ?",
                    (member.guild.id,),
                ) as cur:
                    rows = await cur.fetchall()
                inv_member = member.guild.get_member(inviter.id)
                if inv_member:
                    for role_id, req in rows:
                        if net >= req:
                            role = member.guild.get_role(role_id)
                            if role and role not in inv_member.roles:
                                try:
                                    await inv_member.add_roles(role)
                                except Exception:
                                    pass

            async with self.bot.db.execute(
                "SELECT join_channel_id, join_message, vanity_message FROM guild_settings WHERE guild_id = ?",
                (member.guild.id,),
            ) as cur:
                row = await cur.fetchone()
            if row:
                ch_id, join_msg, vanity_msg = row
                channel = member.guild.get_channel(ch_id) if ch_id else None
                if channel:
                    raw = vanity_msg if used_vanity and vanity_msg else join_msg
                    if raw:
                        text = await self._replace_message_variables(
                            raw, member, inviter, member.guild
                        )
                        await channel.send(text)
                    else:
                        inviter_text = (
                            inviter.mention
                            if inviter
                            else ("Vanity invite" if used_vanity else "Unknown")
                        )
                        embed = discord.Embed(
                            description=(
                                f"Welcome {member.mention} to **{member.guild.name}**!\n"
                                f"{DOT} Invited by: {inviter_text}\n"
                                f"{DOT} You are member **#{member.guild.member_count}**"
                            ),
                            color=COLOR,
                        )
                        embed.set_thumbnail(url=member.display_avatar.url)
                        await channel.send(embed=embed)

            async with self.bot.db.execute(
                "SELECT channel_id, greet_type FROM greet_channels WHERE guild_id = ?",
                (member.guild.id,),
            ) as cur:
                greet_rows = await cur.fetchall()
            for g_ch_id, g_type in greet_rows:
                g_ch = member.guild.get_channel(g_ch_id)
                if not g_ch:
                    continue
                if g_type == "embed":
                    embed = discord.Embed(
                        description=f"👋 Welcome {member.mention} to **{member.guild.name}**!",
                        color=COLOR,
                    )
                    embed.set_thumbnail(url=member.display_avatar.url)
                    await g_ch.send(embed=embed)
                else:
                    await g_ch.send(f"👋 Welcome {member.mention} to **{member.guild.name}**!")
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        await update_user(self.bot, member.id, left=1)
        try:
            async with self.bot.db.execute(
                "SELECT leave_channel_id, leave_message FROM guild_settings WHERE guild_id = ?",
                (member.guild.id,),
            ) as cur:
                row = await cur.fetchone()
            if row:
                ch_id, leave_msg = row
                channel = member.guild.get_channel(ch_id) if ch_id else None
                if channel:
                    if leave_msg:
                        text = (
                            leave_msg.replace("{user}", member.mention)
                            .replace("{username}", member.name)
                            .replace("{server}", member.guild.name)
                            .replace("{membercount}", str(member.guild.member_count))
                        )
                        await channel.send(text)
                    else:
                        embed = discord.Embed(
                            description=(
                                f"**{member.name}** has left **{member.guild.name}**.\n"
                                f"{DOT} Members: **{member.guild.member_count}**"
                            ),
                            color=0xFF0000,
                        )
                        await channel.send(embed=embed)
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_message(self, message):
        """Message tracking only. Command processing is handled by Bot.on_message (once)."""
        if message.author.bot:
            return

        # Prefix reply when bot is mentioned at start
        if self.bot.user and self.bot.user.mentioned_in(message) and message.content.startswith(
            self.bot.user.mention
        ):
            await message.reply("My Prefix Here Is `,`", mention_author=False)
            return

        # Blacklisted users: skip tracking (commands blocked via global check in main)
        if await is_bot_blacklisted(self.bot, message.author.id):
            return

        if not message.guild:
            return

        # Blacklisted channels / categories: do not count messages (commands still work)
        async with self.bot.db.execute(
            "SELECT channel_id FROM blacklisted_channels WHERE guild_id = ? AND channel_id = ?",
            (message.guild.id, message.channel.id),
        ) as cur:
            if await cur.fetchone():
                return
        if message.channel.category_id:
            async with self.bot.db.execute(
                "SELECT category_id FROM blacklisted_categories WHERE guild_id = ? AND category_id = ?",
                (message.guild.id, message.channel.category_id),
            ) as cur:
                if await cur.fetchone():
                    return

        await update_user(self.bot, message.author.id, total_msgs=1, weekly_msgs=1, today_msgs=1)
        _, _, _, total_msgs, _, _, _, _, _ = await get_user_data(self.bot, message.author.id)
        async with self.bot.db.execute(
            "SELECT role_id, required_msgs FROM message_roles WHERE guild_id = ?",
            (message.guild.id,),
        ) as cur:
            rows = await cur.fetchall()
        for role_id, req in rows:
            if total_msgs >= req:
                role = message.guild.get_role(role_id)
                if role and role not in message.author.roles:
                    try:
                        await message.author.add_roles(role)
                    except Exception:
                        pass


async def setup(bot):
    await bot.add_cog(Events(bot))
