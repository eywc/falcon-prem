"""
Enable / disable commands and modules per guild.
"""
import discord
from discord.ext import commands

from config import COLOR
from utils.emojis import DOT


class ManageCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="disable")
    @commands.has_permissions(manage_guild=True)
    async def disable(self, ctx, mode: str, *, target: str):
        """Disable a command or module. Usage: ,disable command <name> | ,disable module <name>"""
        if mode == "command":
            await self.bot.db.execute(
                "INSERT OR IGNORE INTO disabled_commands (guild_id, command_name, channel_id) VALUES (?, ?, ?)",
                (ctx.guild.id, target.lower(), 0),
            )
            await self.bot.db.commit()
            embed = discord.Embed(
                color=COLOR,
                description=f"{DOT} Command `{target}` has been **disabled** in this server.",
            )
        elif mode == "module":
            await self.bot.db.execute(
                "INSERT OR IGNORE INTO disabled_modules (guild_id, module_name, channel_id) VALUES (?, ?, ?)",
                (ctx.guild.id, target.lower(), 0),
            )
            await self.bot.db.commit()
            embed = discord.Embed(
                color=COLOR,
                description=f"{DOT} Module `{target}` has been **disabled** in this server.",
            )
        else:
            embed = discord.Embed(
                color=COLOR,
                description=f"❌ Usage: `,disable command <name>` or `,disable module <name>`",
            )
        await ctx.send(embed=embed)

    @commands.command(name="enable")
    @commands.has_permissions(manage_guild=True)
    async def enable(self, ctx, mode: str, *, target: str):
        """Enable a command or module. Usage: ,enable command <name> | ,enable module <name>"""
        if mode == "command":
            await self.bot.db.execute(
                "DELETE FROM disabled_commands WHERE guild_id=? AND command_name=?",
                (ctx.guild.id, target.lower()),
            )
            await self.bot.db.commit()
            embed = discord.Embed(
                color=COLOR, description=f"{DOT} Command `{target}` has been **enabled**."
            )
        elif mode == "module":
            await self.bot.db.execute(
                "DELETE FROM disabled_modules WHERE guild_id=? AND module_name=?",
                (ctx.guild.id, target.lower()),
            )
            await self.bot.db.commit()
            embed = discord.Embed(
                color=COLOR, description=f"{DOT} Module `{target}` has been **enabled**."
            )
        else:
            embed = discord.Embed(
                color=COLOR,
                description=f"❌ Usage: `,enable command <name>` or `,enable module <name>`",
            )
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(ManageCommands(bot))
