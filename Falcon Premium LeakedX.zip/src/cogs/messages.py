"""
Message counting, roles, and channel/category blacklist commands.
"""
import discord
from discord.ext import commands

from config import COLOR
from utils.emojis import DOT
from utils.database import update_user, get_user_data


class Messages(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="messages")
    async def messages_cmd(self, ctx, user: discord.Member = None):
        user = user or ctx.author
        _, _, _, total, weekly, today, _, _, _ = await get_user_data(self.bot, user.id)
        embed = discord.Embed(color=COLOR, title=f"{user.name}'s Messages")
        embed.description = (
            f"**All time • {total}** messages\n"
            f"**Weekly • {weekly}** messages\n"
            f"**Today • {today}** messages\n\n"
            f"*Updated in real-time*"
        )
        await ctx.send(embed=embed)

    @commands.command(name="m")
    async def m_cmd(self, ctx, user: discord.Member = None):
        await self.messages_cmd(ctx, user)

    @commands.command(name="addmessages")
    @commands.has_permissions(administrator=True)
    async def addmessages(self, ctx, user: discord.Member, amount: int):
        await update_user(self.bot, user.id, total_msgs=amount)
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} Added **{amount}** messages to {user.mention}."
        )
        await ctx.send(embed=embed)

    @commands.command(name="removemessages")
    @commands.has_permissions(administrator=True)
    async def removemessages(self, ctx, user: discord.Member, amount: int):
        await update_user(self.bot, user.id, total_msgs=-amount)
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} Removed **{amount}** messages from {user.mention}."
        )
        await ctx.send(embed=embed)

    @commands.command(name="blacklistchannel")
    @commands.has_permissions(manage_guild=True)
    async def blacklistchannel(self, ctx, channel: discord.TextChannel = None):
        channel = channel or ctx.channel
        await self.bot.db.execute(
            "INSERT OR IGNORE INTO blacklisted_channels (guild_id, channel_id) VALUES (?, ?)",
            (ctx.guild.id, channel.id),
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} {channel.mention} is now blacklisted."
        )
        await ctx.send(embed=embed)

    @commands.command(name="unblacklistchannel")
    @commands.has_permissions(manage_guild=True)
    async def unblacklistchannel(self, ctx, channel: discord.TextChannel = None):
        channel = channel or ctx.channel
        await self.bot.db.execute(
            "DELETE FROM blacklisted_channels WHERE guild_id=? AND channel_id=?",
            (ctx.guild.id, channel.id),
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} {channel.mention} has been unblacklisted."
        )
        await ctx.send(embed=embed)

    @commands.command(name="blacklistedchannels")
    async def blacklistedchannels(self, ctx):
        async with self.bot.db.execute(
            "SELECT channel_id FROM blacklisted_channels WHERE guild_id=?", (ctx.guild.id,)
        ) as cur:
            rows = await cur.fetchall()
        embed = discord.Embed(color=COLOR, title="🚫 Blacklisted Channels")
        embed.description = (
            "\n".join([f"{DOT} <#{r[0]}>" for r in rows])
            if rows
            else f"{DOT} No blacklisted channels."
        )
        await ctx.send(embed=embed)

    @commands.command(name="blacklistcategory")
    @commands.has_permissions(manage_guild=True)
    async def blacklistcategory(self, ctx, *, category_name: str):
        cat = discord.utils.get(ctx.guild.categories, name=category_name)
        if not cat:
            return await ctx.send(f"❌ Category `{category_name}` not found.")
        await self.bot.db.execute(
            "INSERT OR IGNORE INTO blacklisted_categories (guild_id, category_id) VALUES (?, ?)",
            (ctx.guild.id, cat.id),
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} Category **{cat.name}** is now blacklisted."
        )
        await ctx.send(embed=embed)

    @commands.command(name="unblacklistcategory")
    @commands.has_permissions(manage_guild=True)
    async def unblacklistcategory(self, ctx, *, category_name: str):
        cat = discord.utils.get(ctx.guild.categories, name=category_name)
        if not cat:
            return await ctx.send(f"❌ Category `{category_name}` not found.")
        await self.bot.db.execute(
            "DELETE FROM blacklisted_categories WHERE guild_id=? AND category_id=?",
            (ctx.guild.id, cat.id),
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} Category **{cat.name}** has been unblacklisted."
        )
        await ctx.send(embed=embed)

    @commands.command(name="blacklistedcategories")
    async def blacklistedcategories(self, ctx):
        async with self.bot.db.execute(
            "SELECT category_id FROM blacklisted_categories WHERE guild_id=?", (ctx.guild.id,)
        ) as cur:
            rows = await cur.fetchall()
        embed = discord.Embed(color=COLOR, title="🚫 Blacklisted Categories")
        if not rows:
            embed.description = f"{DOT} No blacklisted categories."
        else:
            lines = []
            for (cat_id,) in rows:
                cat = ctx.guild.get_channel(cat_id)
                lines.append(f"{DOT} **{cat.name if cat else f'Unknown ({cat_id})'}**")
            embed.description = "\n".join(lines)
        await ctx.send(embed=embed)

    @commands.command(name="setmessagerole")
    @commands.has_permissions(manage_guild=True)
    async def setmessagerole(self, ctx, role: discord.Role, count: int):
        await self.bot.db.execute(
            "INSERT OR REPLACE INTO message_roles (guild_id, role_id, required_msgs) VALUES (?, ?, ?)",
            (ctx.guild.id, role.id, count),
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR,
            description=f"{DOT} Members will receive {role.mention} when they reach **{count}** messages.",
        )
        await ctx.send(embed=embed)

    @commands.command(name="unsetmessagerole")
    @commands.has_permissions(manage_guild=True)
    async def unsetmessagerole(self, ctx, role: discord.Role):
        await self.bot.db.execute(
            "DELETE FROM message_roles WHERE guild_id=? AND role_id=?", (ctx.guild.id, role.id)
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} Message role reward for {role.mention} removed."
        )
        await ctx.send(embed=embed)

    @commands.command(name="viewmessageroles")
    async def viewmessageroles(self, ctx):
        async with self.bot.db.execute(
            "SELECT role_id, required_msgs FROM message_roles WHERE guild_id=? ORDER BY required_msgs ASC",
            (ctx.guild.id,),
        ) as cur:
            rows = await cur.fetchall()
        embed = discord.Embed(color=COLOR, title="📨 Message Role Rewards")
        embed.description = (
            "\n".join([f"{DOT} <@&{r[0]}> — **{r[1]}** messages required" for r in rows])
            if rows
            else f"{DOT} No message role rewards configured."
        )
        await ctx.send(embed=embed)

    @commands.command(name="clearmsgs")
    @commands.has_permissions(administrator=True)
    async def clearmsgs(self, ctx, user: discord.Member = None):
        if user:
            await self.bot.db.execute(
                "UPDATE users SET total_msgs=0, weekly_msgs=0, today_msgs=0 WHERE user_id=?",
                (user.id,),
            )
            embed = discord.Embed(
                color=COLOR, description=f"{DOT} Cleared messages for {user.mention}."
            )
        else:
            await self.bot.db.execute(
                "UPDATE users SET total_msgs=0, weekly_msgs=0, today_msgs=0"
            )
            embed = discord.Embed(
                color=COLOR,
                description=f"{DOT} Cleared **all** members' messages in this guild.",
            )
        await self.bot.db.commit()
        await ctx.send(embed=embed)

    @commands.command(name="resetmymessages")
    async def resetmymessages(self, ctx):
        await self.bot.db.execute(
            "UPDATE users SET total_msgs=0, weekly_msgs=0, today_msgs=0 WHERE user_id=?",
            (ctx.author.id,),
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR,
            description=f"{DOT} Your message stats have been reset, {ctx.author.mention}.",
        )
        await ctx.send(embed=embed)

    @commands.command(name="setresettime")
    @commands.has_permissions(manage_guild=True)
    async def setresettime(self, ctx, mode: str, *, time: str):
        """Set weekly/daily message or voice reset time. e.g. ,setresettime weeklymessage 00:00"""
        col_map = {
            "weeklymessage": "msg_weekly_reset",
            "dailymessage": "msg_daily_reset",
            "dailyvoice": "voice_daily_reset",
            "weeklyvoice": "voice_weekly_reset",
        }
        col = col_map.get(mode.lower())
        if not col:
            return await ctx.send(
                "❌ Mode must be one of: `weeklymessage`, `dailymessage`, `dailyvoice`, `weeklyvoice`"
            )
        await self.bot.db.execute(
            f"INSERT INTO guild_settings (guild_id, {col}) VALUES (?, ?) "
            f"ON CONFLICT(guild_id) DO UPDATE SET {col}=excluded.{col}",
            (ctx.guild.id, time),
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} Reset time for **{mode}** set to `{time}`."
        )
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Messages(bot))
