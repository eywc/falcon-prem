"""
Poll commands: createpoll, epoll.
"""
import json

import discord
from discord.ext import commands

from config import COLOR
from utils.emojis import DOT


class Polls(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="createpoll")
    @commands.has_permissions(manage_guild=True)
    async def createpoll(self, ctx, *, args: str):
        """Create a poll. Usage: ,createpoll Question | Option1 | Option2 | Option3"""
        parts = [p.strip() for p in args.split("|")]
        if len(parts) < 2:
            return await ctx.send("❌ Usage: `,createpoll Question | Option1 | Option2`")
        question = parts[0]
        options = parts[1:]
        emojis = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
        desc = "\n".join([f"{emojis[i]} {opt}" for i, opt in enumerate(options[:10])])
        embed = discord.Embed(color=COLOR, title=f"📊 {question}", description=desc)
        embed.set_footer(text=f"Poll by {ctx.author.name}", icon_url=ctx.author.display_avatar.url)
        msg = await ctx.send(embed=embed)
        for i in range(min(len(options), 10)):
            await msg.add_reaction(emojis[i])
        await self.bot.db.execute(
            "INSERT INTO polls (msg_id, question, options, channel_id, active) VALUES (?, ?, ?, ?, 1)",
            (msg.id, question, json.dumps(options), ctx.channel.id),
        )
        await self.bot.db.commit()

    @commands.command(name="epoll")
    @commands.has_permissions(manage_guild=True)
    async def epoll(self, ctx):
        """Ends an active poll. Reply to the poll message."""
        if not ctx.message.reference:
            return await ctx.send("❌ Reply to a poll message to end it.")
        msg_id = ctx.message.reference.message_id
        async with self.bot.db.execute(
            "SELECT question, options, channel_id FROM polls WHERE msg_id=? AND active=1", (msg_id,)
        ) as cur:
            row = await cur.fetchone()
        if not row:
            return await ctx.send("❌ No active poll found.")
        question, options_json, ch_id = row
        options = json.loads(options_json)
        channel = ctx.guild.get_channel(ch_id)
        try:
            poll_msg = await channel.fetch_message(msg_id)
        except Exception:
            return await ctx.send("❌ Could not fetch poll message.")
        emojis = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
        results = []
        for i, opt in enumerate(options[:10]):
            for r in poll_msg.reactions:
                if str(r.emoji) == emojis[i]:
                    results.append((opt, r.count - 1))
                    break
            else:
                results.append((opt, 0))
        results.sort(key=lambda x: x[1], reverse=True)
        desc = "\n".join([f"{DOT} **{opt}** — {votes} vote(s)" for opt, votes in results])
        embed = discord.Embed(color=COLOR, title=f"📊 Poll Ended: {question}", description=desc)
        embed.set_footer(text="Poll ended")
        await poll_msg.edit(embed=embed)
        await self.bot.db.execute("UPDATE polls SET active=0 WHERE msg_id=?", (msg_id,))
        await self.bot.db.commit()
        await ctx.send(
            embed=discord.Embed(color=COLOR, description=f"{DOT} Poll ended successfully."),
            delete_after=5,
        )


async def setup(bot):
    await bot.add_cog(Polls(bot))
