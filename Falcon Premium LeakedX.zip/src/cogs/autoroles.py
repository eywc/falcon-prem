"""
Auto-role commands.
"""
import discord
from discord.ext import commands

from config import COLOR
from utils.emojis import DOT, ARROW


class AutoRoles(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="autorole")
    @commands.has_permissions(manage_guild=True)
    async def autorole(self, ctx):
        embed = discord.Embed(
            color=COLOR,
            title="Auto Roles",
            description="Automatically assign roles to new users\n\n**Commands**",
        )
        embed.description += (
            f"\n{ARROW} `,autorole` — Get list of all autorole commands"
            f"\n{ARROW} `,setautorole` — Set autorole for humans and bots"
            f"\n{ARROW} `,unsetautorole` — Delete an autorole"
            f"\n{ARROW} `,configscreening` — Add role after membership screening"
            f"\n{ARROW} `,viewautoroles` — Displays a guild's autoroles"
        )
        await ctx.send(embed=embed)

    @commands.command(name="setautorole")
    @commands.has_permissions(manage_guild=True)
    async def setautorole(self, ctx, role: discord.Role, role_type: str = "all"):
        """Set an autorole. role_type: all, humans, bots"""
        if role_type not in ("all", "humans", "bots"):
            return await ctx.send("❌ role_type must be `all`, `humans`, or `bots`.")
        await self.bot.db.execute(
            "INSERT OR REPLACE INTO autoroles (guild_id, role_id, role_type) VALUES (?, ?, ?)",
            (ctx.guild.id, role.id, role_type),
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} AutoRole set: {role.mention} for **{role_type}**."
        )
        await ctx.send(embed=embed)

    @commands.command(name="unsetautorole")
    @commands.has_permissions(manage_guild=True)
    async def unsetautorole(self, ctx, role: discord.Role):
        await self.bot.db.execute(
            "DELETE FROM autoroles WHERE guild_id=? AND role_id=?", (ctx.guild.id, role.id)
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} AutoRole for {role.mention} removed."
        )
        await ctx.send(embed=embed)

    @commands.command(name="configscreening")
    @commands.has_permissions(manage_guild=True)
    async def configscreening(self, ctx, role: discord.Role):
        """This feature will add role to users after they complete membership screening."""
        embed = discord.Embed(
            color=COLOR,
            description=(
                f"{DOT} Screening role set to {role.mention}. "
                "Note: Discord API handles this natively via membership screening."
            ),
        )
        await ctx.send(embed=embed)

    @commands.command(name="viewautoroles")
    async def viewautoroles(self, ctx):
        async with self.bot.db.execute(
            "SELECT role_id, role_type FROM autoroles WHERE guild_id=?", (ctx.guild.id,)
        ) as cur:
            rows = await cur.fetchall()
        embed = discord.Embed(color=COLOR, title=" 🎭 Auto Roles")
        embed.description = (
            "\n".join([f"{DOT} <@&{r[0]}> — `{r[1]}`" for r in rows])
            if rows
            else f"{DOT} No autoroles configured."
        )
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(AutoRoles(bot))
