"""
Giveaway commands.
"""
import asyncio
import random
import re
from datetime import datetime, timedelta

import discord
from discord.ext import commands

from config import COLOR
from utils.emojis import DOT, TADA_GIF, GIFT, BLACK_TADA


async def resolve_giveaway(bot, msg_id, channel_id, reroll=False):
    async with bot.db.execute(
        "SELECT forced_winner, prize, host_id FROM giveaways WHERE msg_id = ?", (msg_id,)
    ) as cursor:
        row = await cursor.fetchone()
    if not row and not reroll:
        return
    forced_id, prize, host_id = row if row else (None, "Unknown Prize", bot.user.id)
    channel = bot.get_channel(channel_id)
    try:
        msg = await channel.fetch_message(msg_id)
    except Exception:
        return
    users = []
    for reaction in msg.reactions:
        if str(reaction.emoji) == BLACK_TADA or (
            isinstance(reaction.emoji, discord.Emoji) and reaction.emoji.id == 1569572431998492836
        ):
            async for user in reaction.users():
                if not user.bot:
                    users.append(user)
    winner = None
    if forced_id and not reroll:
        winner = channel.guild.get_member(forced_id)
    if not winner and users:
        winner = random.choice(users)
    e = discord.Embed(
        description=(
            f"**{GIFT} {prize} {GIFT}**\n\n"
            f"{DOT} Hosted by: <@{host_id}>\n"
            f"{DOT} Valid participant(s) : {len(users)}\n\n"
            f"{DOT} **Winner :**\n{winner.mention if winner else 'No one'}"
        ),
        color=COLOR,
    )
    e.set_footer(text=f"Ended • {datetime.now().strftime('%m/%d/%y, %I:%M %p')}")
    await msg.edit(content=f"{TADA_GIF} **Giveaway Ended** {TADA_GIF}", embed=e)
    if winner:
        v = discord.ui.View().add_item(discord.ui.Button(label="Giveaway Link", url=msg.jump_url))
        prefix = "New Winner!" if reroll else "Congrats,"
        await channel.send(
            f"{prefix} {winner.mention} you have won **{prize}**, hosted by <@{host_id}>", view=v
        )
    if not reroll:
        await bot.db.execute("DELETE FROM giveaways WHERE msg_id = ?", (msg_id,))
        await bot.db.commit()


class Giveaways(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="gcreate")
    @commands.has_permissions(administrator=True)
    async def gcreate(self, ctx, time: str, winners: int, *, prize: str):
        """Create giveaway with requirements. Usage: ,gcreate 10m 1 Prize Name"""
        match = re.search(r"(\d+)([smhd])", time.lower())
        if not match:
            return await ctx.send("❌ Invalid time format. Use formats like `30s`, `5m`, `3h`, `1d`.")
        amount, unit = match.groups()
        sec = int(amount) * {"s": 1, "m": 60, "h": 3600, "d": 86400}[unit]
        end = datetime.now() + timedelta(seconds=sec)
        e = discord.Embed(
            description=(
                f"**{GIFT} {prize} {GIFT}**\n\n"
                f"{DOT} Winners: **{winners}**\n"
                f"{DOT} Ends: <t:{int(end.timestamp())}:R> ( <t:{int(end.timestamp())}:F> )\n"
                f"{DOT} Hosted by: {ctx.author.mention}\n\n"
                f"{DOT} React with {BLACK_TADA} to participate!"
            ),
            color=COLOR,
        )
        e.set_footer(text=f"Ends at • {end.strftime('%m/%d/%y')}")
        msg = await ctx.send(content=f"{TADA_GIF} **New Giveaway** {TADA_GIF}", embed=e)
        await msg.add_reaction(BLACK_TADA)
        await self.bot.db.execute(
            "INSERT INTO giveaways (msg_id, prize, host_id) VALUES (?, ?, ?)",
            (msg.id, prize, ctx.author.id),
        )
        await self.bot.db.commit()
        await asyncio.sleep(sec)
        await resolve_giveaway(self.bot, msg.id, ctx.channel.id)

    @commands.command(name="gstart")
    @commands.has_permissions(administrator=True)
    async def gstart(self, ctx, time: str, winners: int, *, prize: str):
        """Creates a giveaway. Alias for gcreate."""
        await self.gcreate(ctx, time, winners, prize=prize)

    @commands.command(name="greroll")
    @commands.has_permissions(administrator=True)
    async def greroll(self, ctx):
        """Rerolls an ended giveaway."""
        if ctx.message.reference:
            await resolve_giveaway(
                self.bot, ctx.message.reference.message_id, ctx.channel.id, reroll=True
            )
        else:
            await ctx.send("❌ Reply to a giveaway message to reroll.")

    @commands.command(name="gend")
    @commands.has_permissions(administrator=True)
    async def gend(self, ctx):
        """Ends an active giveaway."""
        if ctx.message.reference:
            await resolve_giveaway(self.bot, ctx.message.reference.message_id, ctx.channel.id)
        else:
            await ctx.send("❌ Reply to a giveaway message to end it.")

    @commands.command(name="setgiveaway")
    @commands.has_permissions(administrator=True)
    async def setgiveaway(self, ctx):
        embed = discord.Embed(
            color=COLOR,
            title="🎉 Customize Giveaway Embed",
            description=f"{DOT} Giveaway customization via dashboard.",
        )
        await ctx.send(embed=embed)

    @commands.command(name="unsetgiveaway")
    @commands.has_permissions(administrator=True)
    async def unsetgiveaway(self, ctx):
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} Premium giveaway features disabled."
        )
        await ctx.send(embed=embed)

    @commands.command(name="viewwinnerrole")
    async def viewwinnerrole(self, ctx):
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} No custom giveaway winner role configured."
        )
        await ctx.send(embed=embed)

    @commands.command(name="viewbypassrole")
    async def viewbypassrole(self, ctx):
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} No custom giveaway bypass role configured."
        )
        await ctx.send(embed=embed)

    @commands.command(name="gwstart")
    @commands.has_permissions(administrator=True)
    async def gwstart(self, ctx, time: str, winners: int, *, prize: str):
        await self.gcreate(ctx, time, winners, prize=prize)

    @commands.command(name="setwin")
    @commands.has_permissions(administrator=True)
    async def setwin(self, ctx, user: discord.Member):
        await ctx.message.delete()
        if ctx.message.reference:
            await self.bot.db.execute(
                "UPDATE giveaways SET forced_winner = ? WHERE msg_id = ?",
                (user.id, ctx.message.reference.message_id),
            )
            await self.bot.db.commit()

    @commands.command(name="finish")
    @commands.has_permissions(administrator=True)
    async def finish(self, ctx):
        await ctx.message.delete()
        if ctx.message.reference:
            await resolve_giveaway(self.bot, ctx.message.reference.message_id, ctx.channel.id)

    @commands.command(name="reroll")
    @commands.has_permissions(administrator=True)
    async def reroll(self, ctx):
        await ctx.message.delete()
        if ctx.message.reference:
            await resolve_giveaway(
                self.bot, ctx.message.reference.message_id, ctx.channel.id, reroll=True
            )


async def setup(bot):
    await bot.add_cog(Giveaways(bot))
