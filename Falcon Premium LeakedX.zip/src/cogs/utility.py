"""
Utility commands: ping, serverinfo, userinfo, avatar, crypto, emoji, about, invite.
"""
import asyncio
import re
from datetime import datetime

import aiohttp
import discord
from discord.ext import commands

from config import COLOR, CLIENT_ID, PRIMARY_OWNER_IDS, PRIMARY_OWNER_ID
from utils.emojis import DOT, ARROW, get_status_emoji
from utils.checks import is_bot_owner


COIN_ALIAS = {
    "btc": "bitcoin", "eth": "ethereum", "sol": "solana", "doge": "dogecoin",
    "xrp": "ripple", "ada": "cardano", "bnb": "binancecoin", "ltc": "litecoin",
    "matic": "matic-network", "dot": "polkadot", "trx": "tron", "shib": "shiba-inu",
    "avax": "avalanche-2", "link": "chainlink", "atom": "cosmos", "ton": "the-open-network",
}

EMOJI_RE = re.compile(r"<(a)?:(\w+):(\d+)>")


class Utility(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="ping")
    async def ping(self, ctx):
        embed = discord.Embed(color=COLOR, description=f"{DOT} Pong! **{round(self.bot.latency * 1000)}ms**")
        await ctx.send(embed=embed)

    @commands.command(name="serverinfo")
    async def serverinfo(self, ctx):
        g = ctx.guild
        embed = discord.Embed(color=COLOR, title=g.name)
        embed.set_thumbnail(url=g.icon.url if g.icon else "")
        embed.add_field(name="Owner", value=g.owner.mention if g.owner else "Unknown", inline=True)
        embed.add_field(name="Members", value=str(g.member_count), inline=True)
        embed.add_field(name="Created", value=f"<t:{int(g.created_at.timestamp())}:R>", inline=True)
        embed.add_field(name="Channels", value=str(len(g.channels)), inline=True)
        embed.add_field(name="Roles", value=str(len(g.roles)), inline=True)
        embed.add_field(name="Boosts", value=str(g.premium_subscription_count), inline=True)
        await ctx.send(embed=embed)

    @commands.command(name="userinfo")
    async def userinfo(self, ctx, user: discord.Member = None):
        user = user or ctx.author
        embed = discord.Embed(color=COLOR, title=f"{user.name}#{user.discriminator}")
        embed.set_thumbnail(url=user.display_avatar.url)
        embed.add_field(name="ID", value=str(user.id), inline=True)
        embed.add_field(name="Status", value=get_status_emoji(user), inline=True)
        embed.add_field(
            name="Joined",
            value=f"<t:{int(user.joined_at.timestamp())}:R>" if user.joined_at else "Unknown",
            inline=True,
        )
        embed.add_field(name="Created", value=f"<t:{int(user.created_at.timestamp())}:R>", inline=True)
        embed.add_field(name="Roles", value=str(len(user.roles) - 1), inline=True)
        await ctx.send(embed=embed)

    @commands.command(name="avatar")
    async def avatar(self, ctx, user: discord.Member = None):
        user = user or ctx.author
        embed = discord.Embed(color=COLOR, title=f"{user.name}'s Avatar")
        embed.set_image(url=user.display_avatar.url)
        await ctx.send(embed=embed)

    @commands.command(name="crypto", aliases=["price"])
    async def crypto_cmd(self, ctx, symbol: str = None):
        if not symbol:
            return await ctx.send(f"{DOT} Usage: `,crypto <symbol>`  e.g. `,crypto btc`")
        coin_id = COIN_ALIAS.get(symbol.lower(), symbol.lower())
        url = (
            f"https://api.coingecko.com/api/v3/coins/{coin_id}"
            "?localization=false&tickers=false&community_data=false&developer_data=false"
        )
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=15) as resp:
                    if resp.status != 200:
                        return await ctx.send(f"{DOT} Coin `{symbol}` not found.")
                    data = await resp.json()
            md = data.get("market_data", {})
            price = md.get("current_price", {}).get("usd", "?")
            change_24h = md.get("price_change_percentage_24h", 0) or 0
            mcap = md.get("market_cap", {}).get("usd", 0) or 0
            vol = md.get("total_volume", {}).get("usd", 0) or 0
            embed = discord.Embed(
                color=COLOR,
                title=f"{data.get('name', '?')} ({data.get('symbol', '').upper()})",
                url=f"https://www.coingecko.com/en/coins/{coin_id}",
            )
            thumb = (data.get("image") or {}).get("large")
            if thumb:
                embed.set_thumbnail(url=thumb)
            sign = "▲" if change_24h >= 0 else "▼"
            embed.add_field(name="Price (USD)", value=f"${price:,}", inline=True)
            embed.add_field(name="24h Change", value=f"{sign} {change_24h:.2f}%", inline=True)
            embed.add_field(name="Market Cap", value=f"${mcap:,.0f}", inline=True)
            embed.add_field(name="24h Volume", value=f"${vol:,.0f}", inline=True)
            rank = md.get("market_cap_rank")
            if rank:
                embed.add_field(name="Rank", value=f"#{rank}", inline=True)
            await ctx.send(embed=embed)
        except asyncio.TimeoutError:
            await ctx.send(f"{DOT} CoinGecko timeout.")
        except Exception as e:
            await ctx.send(f"{DOT} Error: {e}")

    @commands.command(name="emoji", aliases=["steal", "einfo"])
    async def emoji_cmd(self, ctx, *, arg: str = None):
        if not arg and not ctx.message.attachments:
            return await ctx.send(f"{DOT} Send an emoji: `,emoji <emoji>`")
        target = arg or ""
        m = EMOJI_RE.search(target)
        if m:
            animated = m.group(1) == "a"
            name = m.group(2)
            eid = m.group(3)
            ext = "gif" if animated else "png"
            url = f"https://cdn.discordapp.com/emojis/{eid}.{ext}?size=512&quality=lossless"
            embed = discord.Embed(color=COLOR, title=f":{name}:")
            embed.add_field(name="Name", value=f"`{name}`", inline=True)
            embed.add_field(name="ID", value=f"`{eid}`", inline=True)
            embed.add_field(name="Animated", value="Yes" if animated else "No", inline=True)
            embed.add_field(name="URL", value=f"[Click]({url})", inline=False)
            embed.set_image(url=url)
            return await ctx.send(embed=embed)
        embed = discord.Embed(color=COLOR, title="Emoji Info")
        embed.description = (
            f"{DOT} Raw: `{target}`\n"
            f"{DOT} Codepoints: `{' '.join(f'U+{ord(c):04X}' for c in target if c.strip())}`"
        )
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="about", description="About Falcon")
    async def about_cmd(self, ctx):
        async with self.bot.db.execute("SELECT user_id FROM bot_owners") as cur:
            extra_owners = [r[0] for r in await cur.fetchall() if r[0] not in PRIMARY_OWNER_IDS]
        async with self.bot.db.execute("SELECT user_id FROM bot_staff") as cur:
            staff = [r[0] for r in await cur.fetchall()]

        primary_lines = "\n".join(
            [f"{ARROW} <@{oid}> (`{oid}`)" for oid in PRIMARY_OWNER_IDS]
        )
        owner_lines = (
            "\n".join([f"{ARROW} <@{oid}>" for oid in extra_owners])
            if extra_owners
            else f"{DOT} *(none)*"
        )
        staff_lines = (
            "\n".join([f"{ARROW} <@{sid}>" for sid in staff]) if staff else f"{DOT} *(none)*"
        )

        embed = discord.Embed(color=COLOR, title="About Falcon Premium")
        embed.description = (
            "A multipurpose Discord bot featuring moderation, automod, anti-nuke, anti-raid, "
            "music, crypto tools, utility commands, and more.\n"
        )
        embed.add_field(name="Primary Owners", value=primary_lines, inline=False)
        embed.add_field(name="Owners", value=owner_lines, inline=False)
        embed.add_field(name="Staff", value=staff_lines, inline=False)
        embed.add_field(name="Servers", value=str(len(self.bot.guilds)), inline=True)
        embed.add_field(
            name="Users",
            value=str(sum(g.member_count or 0 for g in self.bot.guilds)),
            inline=True,
        )
        embed.add_field(name="Latency", value=f"{round(self.bot.latency * 1000)} ms", inline=True)
        embed.set_footer(text="Falcon Premium • Multi-purpose")
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="invite", description="Get Falcon Premium invite links")
    async def invite_cmd(self, ctx):
        embed = discord.Embed(
            color=COLOR,
            title="Falcon Premium bot Invite",
            description=(
                f"Invite Falcon Premium by clicking on this link:\n"
                f"With sufficient permissions [Click here to invite]"
                f"(https://discord.com/oauth2/authorize?client_id={CLIENT_ID}&permissions=268823806&scope=bot%20applications.commands)\n\n"
                f"Invite Falcon Premium by clicking on this link:\n"
                f"With admin permissions [Click here to invite]"
                f"(https://discord.com/oauth2/authorize?client_id={CLIENT_ID}&permissions=8&scope=bot%20applications.commands)"
            ),
        )
        embed.set_footer(text=f"Requested by - {ctx.author}")
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Utility(bot))
