"""
Moderation commands, automod, anti-raid, and anti-nuke V2.
"""
import asyncio
import re
from collections import defaultdict, deque
from datetime import datetime, timedelta

import discord
from discord.ext import commands

from config import COLOR, PRIMARY_OWNER_IDS
from utils.emojis import DOT, ARROW
from utils.helpers import parse_duration
from utils.checks import is_bot_owner

INVITE_RE = re.compile(r"(discord\.gg|discord(?:app)?\.com/invite)/[A-Za-z0-9-]+", re.I)
LINK_RE = re.compile(r"https?://\S+", re.I)
_spam_buckets = defaultdict(lambda: deque(maxlen=10))
_AN_AUDIT_TS = {}
_AN_AUDIT_COOLDOWN = {}

ANTINUKE_EVENTS = {
    "channel_delete": "Channel Deletion",
    "channel_create": "Channel Creation",
    "channel_update": "Channel Update",
    "role_delete": "Role Deletion",
    "role_create": "Role Creation",
    "role_update": "Role Update",
    "ban": "Member Ban",
    "kick": "Member Kick",
    "bot_add": "Bot Add",
    "webhook_create": "Webhook Create",
    "webhook_delete": "Webhook Delete",
    "everyone": "@everyone Mention",
    "guild_update": "Server Edit",
}


def _an_can_fetch(guild_id, event_name, max_req=5, interval=10, cooldown=300):
    key = (guild_id, event_name)
    now = datetime.now().timestamp()
    until = _AN_AUDIT_COOLDOWN.get(key)
    if until and now < until:
        return False
    elif until:
        _AN_AUDIT_COOLDOWN.pop(key, None)
    ts = _AN_AUDIT_TS.setdefault(key, [])
    ts.append(now)
    ts[:] = [t for t in ts if now - t <= interval]
    if len(ts) > max_req:
        _AN_AUDIT_COOLDOWN[key] = now + cooldown
        return False
    return True


class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="kick")
    @commands.has_permissions(kick_members=True)
    async def kick(self, ctx, member: discord.Member, *, reason: str = "No reason provided"):
        await member.kick(reason=reason)
        await ctx.send(embed=discord.Embed(color=COLOR, description=f"{DOT} **{member.name}** has been kicked.\n{DOT} Reason: {reason}"))

    @commands.command(name="ban")
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx, member: discord.Member, *, reason: str = "No reason provided"):
        await member.ban(reason=reason)
        await ctx.send(embed=discord.Embed(color=COLOR, description=f"{DOT} **{member.name}** has been banned.\n{DOT} Reason: {reason}"))

    @commands.command(name="unban")
    @commands.has_permissions(ban_members=True)
    async def unban(self, ctx, user_id: int):
        try:
            user = await self.bot.fetch_user(user_id)
            await ctx.guild.unban(user)
            await ctx.send(embed=discord.Embed(color=COLOR, description=f"{DOT} **{user.name}** has been unbanned."))
        except Exception:
            await ctx.send("❌ User not found or not banned.")

    @commands.command(name="mute")
    @commands.has_permissions(moderate_members=True)
    async def mute(self, ctx, member: discord.Member, time_str: str = "10m", *, reason: str = "No reason provided"):
        seconds = parse_duration(time_str)
        if not seconds:
            return await ctx.send("❌ Invalid time format.")
        until = discord.utils.utcnow() + timedelta(seconds=seconds)
        await member.timeout(until, reason=reason)
        await ctx.send(embed=discord.Embed(color=COLOR, description=f"{DOT} **{member.name}** has been muted for `{time_str}`.\n{DOT} Reason: {reason}"))

    @commands.command(name="unmute")
    @commands.has_permissions(moderate_members=True)
    async def unmute(self, ctx, member: discord.Member):
        await member.timeout(None)
        await ctx.send(embed=discord.Embed(color=COLOR, description=f"{DOT} **{member.name}** has been unmuted."))

    @commands.command(name="erase")
    @commands.has_permissions(manage_messages=True)
    async def erase(self, ctx, amount: int = 10):
        await ctx.channel.purge(limit=amount + 1)
        await ctx.send(embed=discord.Embed(color=COLOR, description=f"{DOT} Deleted **{amount}** messages."), delete_after=3)

    async def _automod_check(self, message):
        try:
            if message.author.guild_permissions.manage_messages:
                return
        except Exception:
            return
        async with self.bot.db.execute(
            "SELECT anti_invite, anti_link, anti_spam FROM automod_settings WHERE guild_id = ?",
            (message.guild.id,),
        ) as cur:
            row = await cur.fetchone()
        if not row:
            return
        anti_invite, anti_link, anti_spam = row
        content = message.content or ""
        reason = None
        if anti_invite and INVITE_RE.search(content):
            reason = "Invite link not allowed"
        elif anti_link and LINK_RE.search(content):
            reason = "Links not allowed"
        if reason:
            try:
                await message.delete()
            except Exception:
                pass
            try:
                await message.channel.send(
                    embed=discord.Embed(color=COLOR, description=f"{DOT} {message.author.mention}, your message was removed: **{reason}**"),
                    delete_after=5,
                )
            except Exception:
                pass
            return
        if anti_spam:
            bucket = _spam_buckets[(message.guild.id, message.author.id)]
            now = datetime.now().timestamp()
            bucket.append(now)
            if len(bucket) >= 5 and (now - bucket[0]) <= 5:
                bucket.clear()
                try:
                    until = discord.utils.utcnow() + timedelta(minutes=5)
                    await message.author.timeout(until, reason="Automod: spam")
                    await message.channel.send(
                        embed=discord.Embed(color=COLOR, description=f"{DOT} {message.author.mention} timed out for **5 minutes** (spam)."),
                        delete_after=8,
                    )
                except Exception:
                    pass

    @commands.Cog.listener("on_message")
    async def automod_listener(self, message):
        if message.author.bot or not message.guild:
            return
        await self._automod_check(message)

    @commands.command(name="automod")
    @commands.has_permissions(manage_guild=True)
    async def automod_cmd(self, ctx, action: str = None, setting: str = None):
        valid = {"invite": "anti_invite", "link": "anti_link", "spam": "anti_spam"}
        if not action or action.lower() == "status":
            async with self.bot.db.execute(
                "SELECT anti_invite, anti_link, anti_spam FROM automod_settings WHERE guild_id = ?",
                (ctx.guild.id,),
            ) as cur:
                row = await cur.fetchone()
            ai, al, asp = row if row else (0, 0, 0)
            embed = discord.Embed(color=COLOR, title="Automod Status")
            embed.description = (
                f"{ARROW} Anti-Invite: {'**ON**' if ai else 'OFF'}\n"
                f"{ARROW} Anti-Link:   {'**ON**' if al else 'OFF'}\n"
                f"{ARROW} Anti-Spam:   {'**ON**' if asp else 'OFF'}\n\n"
                f"Use `,automod enable invite|link|spam` or `,automod disable invite|link|spam`"
            )
            return await ctx.send(embed=embed)
        if action.lower() in ("enable", "disable") and setting and setting.lower() in valid:
            col = valid[setting.lower()]
            val = 1 if action.lower() == "enable" else 0
            await self.bot.db.execute(
                f"INSERT INTO automod_settings (guild_id, {col}) VALUES (?, ?) ON CONFLICT(guild_id) DO UPDATE SET {col}=excluded.{col}",
                (ctx.guild.id, val),
            )
            await self.bot.db.commit()
            return await ctx.send(embed=discord.Embed(color=COLOR, description=f"{DOT} Automod **{setting}** {'enabled' if val else 'disabled'}."))
        await ctx.send(f"{DOT} Usage: `,automod enable|disable invite|link|spam` or `,automod status`")

    @commands.Cog.listener("on_member_join")
    async def antiraid_listener(self, member):
        async with self.bot.db.execute(
            "SELECT enabled, join_limit, window_seconds FROM antiraid_settings WHERE guild_id=?",
            (member.guild.id,),
        ) as cur:
            row = await cur.fetchone()
        if not row or not row[0]:
            return
        _, limit, window = row
        dq = self.bot.recent_joins[member.guild.id]
        now = datetime.now().timestamp()
        dq.append((now, member.id))
        recent = [m for t, m in dq if now - t <= window]
        if len(recent) >= limit:
            for uid in recent:
                m = member.guild.get_member(uid)
                if m and not m.bot:
                    try:
                        await m.kick(reason="Anti-Raid: mass join")
                    except Exception:
                        pass
            dq.clear()
            ch = member.guild.system_channel
            if ch:
                try:
                    await ch.send(embed=discord.Embed(color=COLOR, description=f"{DOT} **Anti-Raid triggered** — kicked {len(recent)} recent joiners."))
                except Exception:
                    pass

    @commands.command(name="antiraid")
    @commands.has_permissions(administrator=True)
    async def antiraid_cmd(self, ctx, action: str = None, limit: int = None, window: int = None):
        if not action:
            async with self.bot.db.execute(
                "SELECT enabled, join_limit, window_seconds FROM antiraid_settings WHERE guild_id=?",
                (ctx.guild.id,),
            ) as cur:
                row = await cur.fetchone()
            en, lim, win = row if row else (0, 5, 10)
            embed = discord.Embed(color=COLOR, title="Anti-Raid")
            embed.description = (
                f"{ARROW} Status: {'**ENABLED**' if en else 'DISABLED'}\n"
                f"{ARROW} Joins threshold: **{lim}**\n"
                f"{ARROW} Window: **{win}** seconds\n\n"
                f"Use `,antiraid enable [limit] [window]` or `,antiraid disable`"
            )
            return await ctx.send(embed=embed)
        if action.lower() == "enable":
            lim = limit or 5
            win = window or 10
            await self.bot.db.execute(
                "INSERT INTO antiraid_settings (guild_id, enabled, join_limit, window_seconds) VALUES (?, 1, ?, ?) ON CONFLICT(guild_id) DO UPDATE SET enabled=1, join_limit=excluded.join_limit, window_seconds=excluded.window_seconds",
                (ctx.guild.id, lim, win),
            )
            await self.bot.db.commit()
            return await ctx.send(embed=discord.Embed(color=COLOR, description=f"{DOT} Anti-Raid **enabled** ({lim} joins / {win}s)."))
        if action.lower() == "disable":
            await self.bot.db.execute(
                "INSERT INTO antiraid_settings (guild_id, enabled) VALUES (?, 0) ON CONFLICT(guild_id) DO UPDATE SET enabled=0",
                (ctx.guild.id,),
            )
            await self.bot.db.commit()
            return await ctx.send(embed=discord.Embed(color=COLOR, description=f"{DOT} Anti-Raid **disabled**."))

    async def _an_audit(self, guild, action, target_id=None, perm="ban_members"):
        if not getattr(guild.me.guild_permissions, perm, False):
            return None
        try:
            async for entry in guild.audit_logs(action=action, limit=3):
                if target_id is not None and getattr(entry.target, "id", None) != target_id:
                    continue
                age = (discord.utils.utcnow() - entry.created_at).total_seconds()
                if age >= 3600:
                    return None
                return entry
        except Exception:
            return None
        return None

    async def _an_event_enabled(self, guild_id, event_name):
        async with self.bot.db.execute("SELECT enabled FROM antinuke_settings WHERE guild_id=?", (guild_id,)) as cur:
            row = await cur.fetchone()
        if not row or not row[0]:
            return False
        async with self.bot.db.execute(
            "SELECT enabled FROM antinuke_v2_events WHERE guild_id=? AND event_name=?",
            (guild_id, event_name),
        ) as cur:
            e = await cur.fetchone()
        if e is not None and not e[0]:
            return False
        return True

    async def _an_is_immune(self, guild, user_id, event_name):
        if user_id == self.bot.user.id or user_id == guild.owner_id or user_id in PRIMARY_OWNER_IDS:
            return True
        if await is_bot_owner(self.bot, user_id):
            return True
        async with self.bot.db.execute(
            "SELECT events FROM antinuke_v2_whitelist WHERE guild_id=? AND user_id=?",
            (guild.id, user_id),
        ) as cur:
            row = await cur.fetchone()
        if row:
            ev = (row[0] or "").strip()
            if ev == "*" or event_name in [x.strip() for x in ev.split(",") if x.strip()]:
                return True
        async with self.bot.db.execute("SELECT whitelist FROM antinuke_settings WHERE guild_id=?", (guild.id,)) as cur:
            row = await cur.fetchone()
        if row and row[0]:
            wl = {int(x) for x in row[0].split(",") if x.strip().isdigit()}
            if user_id in wl:
                return True
        return False

    async def _an_punish(self, guild, executor, reason, retries=3):
        member = guild.get_member(executor.id) if hasattr(executor, "id") else None
        while retries > 0:
            try:
                await guild.ban(executor, reason=f"Anti-Nuke V2: {reason}")
                return True
            except discord.Forbidden:
                if member:
                    try:
                        for r in list(member.roles):
                            if r.is_default():
                                continue
                            try:
                                await member.remove_roles(r, reason=f"Anti-Nuke V2: {reason}")
                            except Exception:
                                pass
                    except Exception:
                        pass
                return False
            except discord.HTTPException as e:
                if e.status == 429:
                    try:
                        ra = float(e.response.headers.get("Retry-After", "1"))
                    except Exception:
                        ra = 1.0
                    await asyncio.sleep(ra)
                    retries -= 1
                else:
                    return False
            except Exception:
                return False
        return False

    async def _an_log(self, guild, title, executor, reason):
        ch = guild.system_channel
        if not ch:
            return
        try:
            await ch.send(embed=discord.Embed(
                color=COLOR,
                title=f"🛡️ Anti-Nuke V2 — {title}",
                description=f"{ARROW} Offender: {executor.mention} (`{executor.id}`)\n{ARROW} Action: **{reason}**",
            ))
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        guild = channel.guild
        if not await self._an_event_enabled(guild.id, "channel_delete"):
            return
        if not _an_can_fetch(guild.id, "channel_delete"):
            return
        entry = await self._an_audit(guild, discord.AuditLogAction.channel_delete, channel.id)
        if not entry or await self._an_is_immune(guild, entry.user.id, "channel_delete"):
            return
        async with self.bot.db.execute("SELECT recreate_channels FROM antinuke_v2_settings WHERE guild_id=?", (guild.id,)) as cur:
            s = await cur.fetchone()
        if (s[0] if s else 1):
            try:
                new_ch = await channel.clone(reason="Anti-Nuke V2: channel restore")
                try:
                    await new_ch.edit(position=channel.position)
                except Exception:
                    pass
            except Exception:
                pass
        await self._an_punish(guild, entry.user, "channel deletion")
        await self._an_log(guild, "Channel Deleted", entry.user, "Channel restored & offender banned")

    @commands.Cog.listener()
    async def on_member_ban(self, guild, user):
        if not await self._an_event_enabled(guild.id, "ban"):
            return
        if not _an_can_fetch(guild.id, "ban"):
            return
        entry = await self._an_audit(guild, discord.AuditLogAction.ban, user.id)
        if not entry or await self._an_is_immune(guild, entry.user.id, "ban"):
            return
        try:
            await guild.unban(user, reason="Anti-Nuke V2: unauthorized ban reverted")
        except Exception:
            pass
        await self._an_punish(guild, entry.user, "unauthorized ban")
        await self._an_log(guild, "Member Banned", entry.user, "Ban reverted & offender banned")

    @commands.command(name="antinuke", aliases=["an"])
    @commands.has_permissions(administrator=True)
    async def antinuke_cmd(self, ctx, *args):
        if not args:
            async with self.bot.db.execute("SELECT enabled FROM antinuke_settings WHERE guild_id=?", (ctx.guild.id,)) as cur:
                row = await cur.fetchone()
            en = bool(row and row[0])
            lines = [f"{ARROW} Status: {'**ENABLED ✅**' if en else '**DISABLED ❌**'}", "", "**Events** (default: all on):"]
            for k, label in ANTINUKE_EVENTS.items():
                lines.append(f"{DOT} `{k}` — {label}: ✅")
            lines += ["", "**Commands:**", "`,antinuke enable` / `,antinuke disable`", "`,antinuke event <name> on|off`", "`,antinuke wl add @user [events,*]`", "`,antinuke wl remove @user`", "`,antinuke wl list`", "`,antinuke config recreate on|off`"]
            return await ctx.send(embed=discord.Embed(color=COLOR, title="🛡️ Anti-Nuke V2", description="\n".join(lines)))
        sub = args[0].lower()
        if sub == "enable":
            await self.bot.db.execute("INSERT INTO antinuke_settings (guild_id, enabled) VALUES (?, 1) ON CONFLICT(guild_id) DO UPDATE SET enabled=1", (ctx.guild.id,))
            await self.bot.db.commit()
            return await ctx.send(embed=discord.Embed(color=COLOR, description=f"{DOT} Anti-Nuke V2 **enabled**. All event guards active."))
        if sub == "disable":
            await self.bot.db.execute("INSERT INTO antinuke_settings (guild_id, enabled) VALUES (?, 0) ON CONFLICT(guild_id) DO UPDATE SET enabled=0", (ctx.guild.id,))
            await self.bot.db.commit()
            return await ctx.send(embed=discord.Embed(color=COLOR, description=f"{DOT} Anti-Nuke V2 **disabled**."))
        if sub == "event" and len(args) >= 3:
            ev, state = args[1].lower(), args[2].lower()
            if ev not in ANTINUKE_EVENTS:
                return await ctx.send(f"{DOT} Unknown event.")
            val = 1 if state in ("on", "enable", "true", "1", "yes") else 0
            await self.bot.db.execute(
                "INSERT INTO antinuke_v2_events (guild_id, event_name, enabled) VALUES (?, ?, ?) ON CONFLICT(guild_id, event_name) DO UPDATE SET enabled=excluded.enabled",
                (ctx.guild.id, ev, val),
            )
            await self.bot.db.commit()
            return await ctx.send(embed=discord.Embed(color=COLOR, description=f"{DOT} Event `{ev}` {'enabled ✅' if val else 'disabled ❌'}."))
        if sub == "wl":
            if len(args) < 2:
                return await ctx.send(f"{DOT} Usage: `,antinuke wl add|remove|list`")
            op = args[1].lower()
            if op == "list":
                async with self.bot.db.execute("SELECT user_id, events FROM antinuke_v2_whitelist WHERE guild_id=?", (ctx.guild.id,)) as cur:
                    rows = await cur.fetchall()
                if not rows:
                    return await ctx.send(f"{DOT} No users whitelisted.")
                lines = [f"{ARROW} <@{uid}> — `{ev or '*'}`" for uid, ev in rows]
                return await ctx.send(embed=discord.Embed(color=COLOR, title="Anti-Nuke V2 Whitelist", description="\n".join(lines)))
            if not ctx.message.mentions:
                return await ctx.send(f"{DOT} Mention a user.")
            target = ctx.message.mentions[0]
            if op == "add":
                ev = args[3] if len(args) >= 4 else "*"
                await self.bot.db.execute(
                    "INSERT INTO antinuke_v2_whitelist (guild_id, user_id, events) VALUES (?, ?, ?) ON CONFLICT(guild_id, user_id) DO UPDATE SET events=excluded.events",
                    (ctx.guild.id, target.id, ev),
                )
                await self.bot.db.commit()
                return await ctx.send(embed=discord.Embed(color=COLOR, description=f"{DOT} {target.mention} whitelisted for events: `{ev}`."))
            if op == "remove":
                await self.bot.db.execute("DELETE FROM antinuke_v2_whitelist WHERE guild_id=? AND user_id=?", (ctx.guild.id, target.id))
                await self.bot.db.commit()
                return await ctx.send(embed=discord.Embed(color=COLOR, description=f"{DOT} {target.mention} removed from whitelist."))
        if sub == "config" and len(args) >= 3 and args[1].lower() == "recreate":
            val = 1 if args[2].lower() in ("on", "enable", "true", "1", "yes") else 0
            await self.bot.db.execute(
                "INSERT INTO antinuke_v2_settings (guild_id, recreate_channels) VALUES (?, ?) ON CONFLICT(guild_id) DO UPDATE SET recreate_channels=excluded.recreate_channels",
                (ctx.guild.id, val),
            )
            await self.bot.db.commit()
            return await ctx.send(embed=discord.Embed(color=COLOR, description=f"{DOT} Channel recreate {'enabled ✅' if val else 'disabled ❌'}."))
        await ctx.send(f"{DOT} Unknown sub-command. Use `,antinuke` to see options.")


async def setup(bot):
    await bot.add_cog(Moderation(bot))
