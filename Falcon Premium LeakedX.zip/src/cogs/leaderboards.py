"""
Leaderboard and live leaderboard commands.
"""
import discord
from discord.ext import commands

from config import COLOR
from utils.emojis import DOT
from utils.database import build_lb_embed


class Leaderboards(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.group(name="leaderboard", aliases=["lb"], invoke_without_command=True)
    async def leaderboard(self, ctx):
        embed = discord.Embed(color=COLOR, title="📊 Leaderboard Commands")
        embed.description = (
            f"{DOT} `,leaderboard invites` — Top 10 inviters\n"
            f"{DOT} `,leaderboard messages` — Top 10 all-time messengers\n"
            f"{DOT} `,leaderboard weeklymessages` — Top 10 weekly\n"
            f"{DOT} `,leaderboard dailymessages` — Top 10 daily\n"
            f"{DOT} `,leaderboard voice` — Top 10 voice (all time)\n"
            f"{DOT} `,leaderboard weeklyvoice` — Top 10 voice (weekly)\n"
            f"{DOT} `,leaderboard dailyvoice` — Top 10 voice (daily)\n"
        )
        await ctx.send(embed=embed)

    @leaderboard.command(name="invites")
    async def lb_invites(self, ctx):
        embed = await build_lb_embed(self.bot, ctx.guild, "invites")
        embed.set_footer(
            text=f"Requested by {ctx.author.name}", icon_url=self.bot.user.display_avatar.url
        )
        await ctx.send(embed=embed)

    @leaderboard.command(name="messages")
    async def lb_messages(self, ctx):
        embed = await build_lb_embed(self.bot, ctx.guild, "messages")
        await ctx.send(embed=embed)

    @leaderboard.command(name="weeklymessages")
    async def lb_weekly(self, ctx):
        embed = await build_lb_embed(self.bot, ctx.guild, "weeklymessages")
        await ctx.send(embed=embed)

    @leaderboard.command(name="dailymessages")
    async def lb_daily(self, ctx):
        embed = await build_lb_embed(self.bot, ctx.guild, "dailymessages")
        await ctx.send(embed=embed)

    @leaderboard.command(name="voice")
    async def lb_voice(self, ctx):
        embed = await build_lb_embed(self.bot, ctx.guild, "voice")
        await ctx.send(embed=embed)

    @leaderboard.command(name="weeklyvoice")
    async def lb_weeklyvoice(self, ctx):
        embed = await build_lb_embed(self.bot, ctx.guild, "weeklyvoice")
        await ctx.send(embed=embed)

    @leaderboard.command(name="dailyvoice")
    async def lb_dailyvoice(self, ctx):
        embed = await build_lb_embed(self.bot, ctx.guild, "dailyvoice")
        await ctx.send(embed=embed)

    @commands.command(name="createlivelb")
    @commands.has_permissions(manage_guild=True)
    async def createlivelb(self, ctx, lb_type: str = "invites"):
        """Create a live leaderboard that updates every 30 seconds. Types: invites, messages, voice"""
        embed = await build_lb_embed(self.bot, ctx.guild, lb_type)
        embed.set_footer(text="Live • Updates every 30 seconds")
        msg = await ctx.send(embed=embed)
        await self.bot.db.execute(
            "INSERT OR REPLACE INTO live_leaderboards (guild_id, channel_id, message_id, lb_type) VALUES (?, ?, ?, ?)",
            (ctx.guild.id, ctx.channel.id, msg.id, lb_type),
        )
        await self.bot.db.commit()
        confirm = discord.Embed(
            color=COLOR,
            description=f"{DOT} Live leaderboard (`{lb_type}`) created! It will update every 30 seconds.",
        )
        await ctx.send(embed=confirm, delete_after=5)

    @commands.command(name="deletelivelb")
    @commands.has_permissions(manage_guild=True)
    async def deletelivelb(self, ctx, lb_type: str = "invites"):
        await self.bot.db.execute(
            "DELETE FROM live_leaderboards WHERE guild_id=? AND lb_type=?",
            (ctx.guild.id, lb_type),
        )
        await self.bot.db.commit()
        embed = discord.Embed(
            color=COLOR, description=f"{DOT} Live leaderboard (`{lb_type}`) deleted."
        )
        await ctx.send(embed=embed)

    @commands.command(name="showlivelbs")
    async def showlivelbs(self, ctx):
        async with self.bot.db.execute(
            "SELECT lb_type, channel_id, message_id FROM live_leaderboards WHERE guild_id=?",
            (ctx.guild.id,),
        ) as cur:
            rows = await cur.fetchall()
        embed = discord.Embed(color=COLOR, title="📊 Live Leaderboards")
        if not rows:
            embed.description = f"{DOT} No live leaderboards configured."
        else:
            lines = [
                f"{DOT} `{lb_type}` — <#{ch_id}> ([Jump](https://discord.com/channels/{ctx.guild.id}/{ch_id}/{msg_id}))"
                for lb_type, ch_id, msg_id in rows
            ]
            embed.description = "\n".join(lines)
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Leaderboards(bot))
