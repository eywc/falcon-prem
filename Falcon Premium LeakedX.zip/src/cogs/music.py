"""
Music commands (yt-dlp + FFmpeg).
"""
import asyncio

import discord
from discord.ext import commands

from config import COLOR
from utils.emojis import DOT, ARROW
from utils.checks import is_user_premium

try:
    import yt_dlp
    YTDL_AVAILABLE = True
except Exception:
    YTDL_AVAILABLE = False

YTDL_OPTS = {
    "format": "bestaudio/best",
    "noplaylist": True,
    "quiet": True,
    "no_warnings": True,
    "default_search": "ytsearch",
    "source_address": "0.0.0.0",
}
FFMPEG_OPTS = {
    "before_options": "-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5",
    "options": "-vn",
}


def _ytdl_extract(query):
    with yt_dlp.YoutubeDL(YTDL_OPTS) as ydl:
        info = ydl.extract_info(query, download=False)
        if "entries" in info:
            info = info["entries"][0]
        return {
            "title": info.get("title", "Unknown"),
            "url": info.get("url"),
            "webpage_url": info.get("webpage_url"),
            "duration": info.get("duration", 0),
            "thumbnail": info.get("thumbnail"),
            "uploader": info.get("uploader", "?"),
        }


async def _play_next(bot, guild):
    queue = bot.music_queues[guild.id]
    if not queue:
        bot.now_playing.pop(guild.id, None)
        return
    track, requester_id = queue.pop(0)
    bot.now_playing[guild.id] = (track, requester_id)
    vc = guild.voice_client
    if not vc:
        return
    try:
        source = discord.FFmpegPCMAudio(track["url"], **FFMPEG_OPTS)
        vc.play(
            source,
            after=lambda e: asyncio.run_coroutine_threadsafe(_play_next(bot, guild), bot.loop),
        )
    except Exception:
        await _play_next(bot, guild)


class Music(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="play", aliases=["p"])
    async def play_cmd(self, ctx, *, query: str = None):
        if not YTDL_AVAILABLE:
            return await ctx.send(f"{DOT} Music library not installed.")
        if not query:
            return await ctx.send(f"{DOT} Usage: `,play <song name or URL>`")
        if not ctx.author.voice or not ctx.author.voice.channel:
            return await ctx.send(f"{DOT} Join a voice channel first.")
        vc = ctx.guild.voice_client
        if not vc:
            try:
                vc = await ctx.author.voice.channel.connect()
            except Exception as e:
                return await ctx.send(f"{DOT} Cannot join voice: {e}")
        msg = await ctx.send(f"{DOT} Searching...")
        try:
            track = await asyncio.to_thread(_ytdl_extract, query)
        except Exception as e:
            return await msg.edit(content=f"{DOT} Search failed: {e}")
        self.bot.music_queues[ctx.guild.id].append((track, ctx.author.id))
        if not vc.is_playing():
            await _play_next(self.bot, ctx.guild)
            await msg.edit(
                content=None,
                embed=discord.Embed(
                    color=COLOR, description=f"{DOT} Now playing: **{track['title']}**"
                ),
            )
        else:
            await msg.edit(
                content=None,
                embed=discord.Embed(
                    color=COLOR,
                    description=(
                        f"{DOT} Queued: **{track['title']}** "
                        f"(position #{len(self.bot.music_queues[ctx.guild.id])})"
                    ),
                ),
            )

    @commands.command(name="skip", aliases=["s"])
    async def skip_cmd(self, ctx):
        vc = ctx.guild.voice_client
        if vc and vc.is_playing():
            vc.stop()
            await ctx.send(embed=discord.Embed(color=COLOR, description=f"{DOT} Skipped."))
        else:
            await ctx.send(f"{DOT} Nothing playing.")

    @commands.command(name="stop")
    async def stop_cmd(self, ctx):
        vc = ctx.guild.voice_client
        if vc:
            self.bot.music_queues[ctx.guild.id].clear()
            self.bot.now_playing.pop(ctx.guild.id, None)
            await vc.disconnect()
            await ctx.send(
                embed=discord.Embed(color=COLOR, description=f"{DOT} Stopped and disconnected.")
            )

    @commands.command(name="queue", aliases=["q"])
    async def queue_cmd(self, ctx):
        queue = self.bot.music_queues[ctx.guild.id]
        np = self.bot.now_playing.get(ctx.guild.id)
        embed = discord.Embed(color=COLOR, title="Music Queue")
        desc = ""
        if np:
            desc += f"**Now Playing:** {np[0]['title']} • <@{np[1]}>\n\n"
        if not queue:
            desc += f"{DOT} Queue is empty."
        else:
            desc += "\n".join(
                [f"`{i+1}.` {t['title']} • <@{rid}>" for i, (t, rid) in enumerate(queue[:15])]
            )
            if len(queue) > 15:
                desc += f"\n…and {len(queue)-15} more"
        embed.description = desc
        await ctx.send(embed=embed)

    @commands.command(name="nowplaying", aliases=["nowp"])
    async def nowplaying_cmd(self, ctx):
        np = self.bot.now_playing.get(ctx.guild.id)
        if not np:
            return await ctx.send(f"{DOT} Nothing playing.")
        track, rid = np
        is_premium = await is_user_premium(self.bot, rid) or await is_user_premium(
            self.bot, ctx.author.id
        )
        embed = discord.Embed(color=COLOR, title="Now Playing")
        if is_premium:
            embed.description = (
                f"**[{track['title']}]({track.get('webpage_url', '')})**\n"
                f"{ARROW} Uploader: `{track.get('uploader', '?')}`\n"
                f"{ARROW} Duration: `{track.get('duration', 0)}s`\n"
                f"{ARROW} Requested by: <@{rid}>"
            )
            if track.get("thumbnail"):
                embed.set_image(url=track["thumbnail"])
            embed.set_footer(text="✨ Premium NP+")
        else:
            embed.description = f"{DOT} **{track['title']}** — requested by <@{rid}>"
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Music(bot))
