"""
Permission / status checks used across cogs.
"""
from datetime import datetime

from config import PRIMARY_OWNER_IDS


async def is_bot_owner(bot, uid: int) -> bool:
    if uid in PRIMARY_OWNER_IDS:
        return True
    async with bot.db.execute("SELECT 1 FROM bot_owners WHERE user_id = ?", (uid,)) as cur:
        return (await cur.fetchone()) is not None


async def is_bot_blacklisted(bot, uid: int) -> bool:
    if uid in PRIMARY_OWNER_IDS:
        return False
    async with bot.db.execute("SELECT 1 FROM user_blacklist WHERE user_id = ?", (uid,)) as cur:
        return (await cur.fetchone()) is not None


async def is_user_premium(bot, uid: int) -> bool:
    if uid in PRIMARY_OWNER_IDS:
        return True
    async with bot.db.execute("SELECT expiry FROM premium_users WHERE user_id = ?", (uid,)) as cur:
        row = await cur.fetchone()
    if not row:
        return False
    try:
        return datetime.fromisoformat(row[0]) > datetime.now()
    except Exception:
        return False


async def is_bot_staff(bot, uid: int) -> bool:
    if await is_bot_owner(bot, uid):
        return True
    async with bot.db.execute("SELECT 1 FROM bot_staff WHERE user_id = ?", (uid,)) as cur:
        return (await cur.fetchone()) is not None
