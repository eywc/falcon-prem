"""
Shared helper functions (time parsing, formatting, etc.).
"""
import re
from datetime import datetime, timedelta


def parse_duration(time_str: str):
    """Parse strings like 30s, 5m, 3h, 1d into total seconds. Returns None on failure."""
    total = 0
    matches = re.findall(r"(\d+(?:\.\d+)?)([smhd])", time_str.lower())
    if not matches:
        return None
    for amount, unit in matches:
        total += float(amount) * {"s": 1, "m": 60, "h": 3600, "d": 86400}[unit]
    return int(total)


def format_seconds(s: int) -> str:
    """Format seconds as 'Xh Ym Zs'."""
    return f"{s // 3600}h {(s % 3600) // 60}m {s % 60}s"


def ordinal(n: int) -> str:
    """Return ordinal suffix for n (1st, 2nd, 3rd, ...)."""
    if 11 <= (n % 100) <= 13:
        return "th"
    return {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")
