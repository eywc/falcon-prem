"""
Custom emoji constants used throughout Falcon Premium Bot.
IDs must stay exactly as in the original bot.
"""

TADA_GIF = "<:tada:1569572431998492836>"
DOT = "<:dot:1569572425316962365>"
GIFT = "<:wvay:1569572429758464030> "
BLACK_TADA = "<:tada:1569572431998492836>"
ARROW = "<:fp_arrow:1569572434787573800>"

# Category emojis
E_NEWS = "<:news:1569572437949947974>"
E_PREMIUM = "<:fp_premium:1569572440269398098> "
E_INVITE = "<:fp_invite:1569572460771414026> "
E_MSG = "<:ms:1569572445101228042> "
E_VOICE = "<:vc:1569572447269691504> "
E_ROLE = "<:fp_premium:1569572440269398098> "
E_LB = "<:lb:1569572450851618827>"
E_GW = "<:tada:1569572431998492836>"
E_TIMER = "<:timer:1569572454743937054>"
E_GREET = "<:wlcm:1569572457168502784> "
E_MOD = "<:mods:1569572459298951210> "
E_MANAGE = "<:fp_invite:1569572460771414026>"
E_POLL = "<:polls:1569572463388524637> "
E_UTILITY = "<:utlity:1569572465737466018> "
E_CONTACT = "<:support:1569572468241334426> "

# Status emojis
ONLINE = "🟢"
OFFLINE = "⚫"
DND = "🔴"
IDLE = "🟡"


def get_status_emoji(member) -> str:
    if member is None:
        return OFFLINE
    s = member.status
    import discord
    if s == discord.Status.online:
        return ONLINE
    elif s == discord.Status.dnd:
        return DND
    elif s == discord.Status.idle:
        return IDLE
    return OFFLINE
