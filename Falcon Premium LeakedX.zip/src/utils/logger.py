"""
Purple-themed console logger for Falcon Premium Bot.
"""
import logging
import os
import sys
from datetime import datetime

# ANSI helpers
def _supports_color() -> bool:
    if os.environ.get("NO_COLOR"):
        return False
    if sys.platform == "win32":
        try:
            import colorama
            colorama.init()
            return True
        except Exception:
            try:
                os.system("")
                return True
            except Exception:
                return False
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


PURPLE = "\033[38;5;141m"
PURPLE_DIM = "\033[38;5;99m"
PURPLE_BRIGHT = "\033[38;5;183m"
YELLOW = "\033[33m"
RED = "\033[31m"
GREEN = "\033[32m"
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
UNDERLINE = "\033[4m"


class PurpleFormatter(logging.Formatter):
    LEVEL_COLORS = {
        logging.DEBUG: PURPLE_DIM,
        logging.INFO: PURPLE,
        logging.WARNING: YELLOW,
        logging.ERROR: RED,
        logging.CRITICAL: RED + BOLD,
    }

    def format(self, record: logging.LogRecord) -> str:
        if not _supports_color():
            ts = datetime.now().strftime("%H:%M:%S")
            return f"[{ts}] [{record.levelname}] {record.getMessage()}"
        ts = datetime.now().strftime("%H:%M:%S")
        level_color = self.LEVEL_COLORS.get(record.levelno, PURPLE)
        return (
            f"{PURPLE_DIM}[{ts}]{RESET} "
            f"{level_color}[{record.levelname}]{RESET} "
            f"{record.getMessage()}"
        )


def setup_logging() -> logging.Logger:
    logger = logging.getLogger("falcon")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(PurpleFormatter())
    logger.addHandler(handler)

    # Silence noisy discord logs
    logging.getLogger("discord").setLevel(logging.WARNING)
    logging.getLogger("discord.http").setLevel(logging.WARNING)
    logging.getLogger("discord.gateway").setLevel(logging.WARNING)
    logging.getLogger("asyncio").setLevel(logging.WARNING)
    return logger


_logger = setup_logging()


def log_info(msg: str) -> None:
    _logger.info(msg)


def log_warning(msg: str) -> None:
    _logger.warning(msg)


def log_error(msg: str) -> None:
    _logger.error(msg)


def log_debug(msg: str) -> None:
    _logger.debug(msg)
