"""
Database connection, schema creation/migrations, and common query helpers.
"""
import aiosqlite
from datetime import datetime

from config import DB_PATH, COLOR
from utils.logger import log_info, log_error


async def init_db(bot) -> aiosqlite.Connection:
    """Connect to SQLite and ensure all tables exist. Returns the connection."""
    db = await aiosqlite.connect(DB_PATH)
    bot.db = db

    await db.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY, joins INTEGER DEFAULT 0,
            left INTEGER DEFAULT 0, bonus INTEGER DEFAULT 0,
            total_msgs INTEGER DEFAULT 0, weekly_msgs INTEGER DEFAULT 0, today_msgs INTEGER DEFAULT 0,
            voice_alltime INTEGER DEFAULT 0, voice_weekly INTEGER DEFAULT 0, voice_daily INTEGER DEFAULT 0
        )""")
    # Migration: add voice columns to existing databases
    for col, default in [("voice_alltime", 0), ("voice_weekly", 0), ("voice_daily", 0)]:
        try:
            await db.execute(f"ALTER TABLE users ADD COLUMN {col} INTEGER DEFAULT {default}")
            await db.commit()
        except Exception:
            pass

    await db.execute("CREATE TABLE IF NOT EXISTS giveaways (msg_id INTEGER PRIMARY KEY, forced_winner INTEGER, prize TEXT, host_id INTEGER)")
    await db.execute("CREATE TABLE IF NOT EXISTS noprefix (user_id INTEGER PRIMARY KEY, expiry TEXT)")
    await db.execute("""
        CREATE TABLE IF NOT EXISTS invite_tracker (
            invitee_id INTEGER PRIMARY KEY,
            inviter_id INTEGER,
            joined_at TEXT
        )""")
    await db.execute("""
        CREATE TABLE IF NOT EXISTS guild_settings (
            guild_id INTEGER PRIMARY KEY,
            join_channel_id INTEGER,
            leave_channel_id INTEGER,
            join_message TEXT,
            leave_message TEXT,
            vanity_message TEXT,
            alt_threshold INTEGER,
            msg_weekly_reset TEXT,
            msg_daily_reset TEXT,
            voice_daily_reset TEXT,
            voice_weekly_reset TEXT
        )""")
    await db.execute("""
        CREATE TABLE IF NOT EXISTS invite_roles (
            guild_id INTEGER,
            role_id INTEGER,
            required_invites INTEGER,
            PRIMARY KEY (guild_id, role_id)
        )""")
    await db.execute("""
        CREATE TABLE IF NOT EXISTS message_roles (
            guild_id INTEGER,
            role_id INTEGER,
            required_msgs INTEGER,
            PRIMARY KEY (guild_id, role_id)
        )""")
    await db.execute("""
        CREATE TABLE IF NOT EXISTS blacklisted_channels (
            guild_id INTEGER,
            channel_id INTEGER,
            PRIMARY KEY (guild_id, channel_id)
        )""")
    await db.execute("""
        CREATE TABLE IF NOT EXISTS blacklisted_categories (
            guild_id INTEGER,
            category_id INTEGER,
            PRIMARY KEY (guild_id, category_id)
        )""")
    await db.execute("""
        CREATE TABLE IF NOT EXISTS greet_channels (
            guild_id INTEGER,
            channel_id INTEGER,
            greet_type TEXT DEFAULT 'embed',
            PRIMARY KEY (guild_id, channel_id)
        )""")
    await db.execute("""
        CREATE TABLE IF NOT EXISTS autoroles (
            guild_id INTEGER,
            role_id INTEGER,
            role_type TEXT DEFAULT 'all',
            PRIMARY KEY (guild_id, role_id)
        )""")
    await db.execute("""
        CREATE TABLE IF NOT EXISTS live_leaderboards (
            guild_id INTEGER,
            channel_id INTEGER,
            message_id INTEGER,
            lb_type TEXT,
            PRIMARY KEY (guild_id, lb_type)
        )""")
    await db.execute("""
        CREATE TABLE IF NOT EXISTS disabled_commands (
            guild_id INTEGER,
            command_name TEXT,
            channel_id INTEGER,
            PRIMARY KEY (guild_id, command_name, channel_id)
        )""")
    await db.execute("""
        CREATE TABLE IF NOT EXISTS disabled_modules (
            guild_id INTEGER,
            module_name TEXT,
            channel_id INTEGER,
            PRIMARY KEY (guild_id, module_name, channel_id)
        )""")
    await db.execute("""
        CREATE TABLE IF NOT EXISTS polls (
            msg_id INTEGER PRIMARY KEY,
            question TEXT,
            options TEXT,
            channel_id INTEGER,
            active INTEGER DEFAULT 1
        )""")
    await db.execute("""
        CREATE TABLE IF NOT EXISTS premium_guilds (
            guild_id INTEGER PRIMARY KEY,
            expiry TEXT
        )""")
    await db.execute("""
        CREATE TABLE IF NOT EXISTS premium_users (
            user_id INTEGER PRIMARY KEY,
            expiry TEXT
        )""")
    await db.execute("""
        CREATE TABLE IF NOT EXISTS guild_help_emojis (
            guild_id INTEGER PRIMARY KEY,
            emojis TEXT
        )""")
    await db.execute("CREATE TABLE IF NOT EXISTS bot_owners (user_id INTEGER PRIMARY KEY)")
    await db.execute("CREATE TABLE IF NOT EXISTS bot_staff (user_id INTEGER PRIMARY KEY)")
    await db.execute("CREATE TABLE IF NOT EXISTS user_blacklist (user_id INTEGER PRIMARY KEY, reason TEXT, by_user INTEGER, at TEXT)")
    await db.execute("""
        CREATE TABLE IF NOT EXISTS automod_settings (
            guild_id INTEGER PRIMARY KEY,
            anti_invite INTEGER DEFAULT 0,
            anti_link INTEGER DEFAULT 0,
            anti_spam INTEGER DEFAULT 0
        )""")
    await db.execute("""
        CREATE TABLE IF NOT EXISTS antinuke_settings (
            guild_id INTEGER PRIMARY KEY,
            enabled INTEGER DEFAULT 0,
            ch_del_limit INTEGER DEFAULT 3,
            role_del_limit INTEGER DEFAULT 3,
            ban_limit INTEGER DEFAULT 3,
            whitelist TEXT DEFAULT ''
        )""")
    await db.execute("""
        CREATE TABLE IF NOT EXISTS antiraid_settings (
            guild_id INTEGER PRIMARY KEY,
            enabled INTEGER DEFAULT 0,
            join_limit INTEGER DEFAULT 5,
            window_seconds INTEGER DEFAULT 10
        )""")
    await db.execute("""
        CREATE TABLE IF NOT EXISTS antinuke_v2_events (
            guild_id INTEGER NOT NULL,
            event_name TEXT NOT NULL,
            enabled INTEGER DEFAULT 1,
            PRIMARY KEY (guild_id, event_name)
        )""")
    await db.execute("""
        CREATE TABLE IF NOT EXISTS antinuke_v2_whitelist (
            guild_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            events TEXT DEFAULT '*',
            PRIMARY KEY (guild_id, user_id)
        )""")
    await db.execute("""
        CREATE TABLE IF NOT EXISTS antinuke_v2_settings (
            guild_id INTEGER PRIMARY KEY,
            recreate_channels INTEGER DEFAULT 1,
            delete_unauthorized INTEGER DEFAULT 1,
            punish_action TEXT DEFAULT 'ban'
        )""")
    await db.commit()
    log_info(f"Database ready at {DB_PATH}")
    return db


async def update_user(bot, user_id: int, **kwargs):
    cols = ", ".join([f"{k} = {k} + ?" for k in kwargs.keys()])
    vals = list(kwargs.values())
    await bot.db.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (user_id,))
    await bot.db.execute(f"UPDATE users SET {cols} WHERE user_id = ?", vals + [user_id])
    await bot.db.commit()


async def get_user_data(bot, user_id: int):
    async with bot.db.execute(
        "SELECT joins, left, bonus, total_msgs, weekly_msgs, today_msgs, "
        "voice_alltime, voice_weekly, voice_daily FROM users WHERE user_id = ?",
        (user_id,),
    ) as cursor:
        row = await cursor.fetchone()
        return row if row else (0, 0, 0, 0, 0, 0, 0, 0, 0)


async def build_lb_embed(bot, guild, lb_type: str):
    import discord
    from utils.emojis import DOT

    members_ids = [m.id for m in guild.members]
    if not members_ids:
        embed = discord.Embed(color=COLOR, title="Leaderboard")
        embed.description = f"{DOT} No data yet."
        return embed

    placeholders = ",".join("?" * len(members_ids))
    col_map = {
        "invites": ("joins - left + bonus", "🏆 Invite Leaderboard"),
        "messages": ("total_msgs", "💬 Message Leaderboard"),
        "weeklymessages": ("weekly_msgs", "📅 Weekly Message Leaderboard"),
        "dailymessages": ("today_msgs", "☀️ Daily Message Leaderboard"),
        "voice": ("voice_alltime", "🎙️ Voice Leaderboard"),
        "weeklyvoice": ("voice_weekly", "📅 Weekly Voice Leaderboard"),
        "dailyvoice": ("voice_daily", "☀️ Daily Voice Leaderboard"),
    }
    col, title = col_map.get(lb_type, ("total_msgs", "Leaderboard"))
    async with bot.db.execute(
        f"SELECT user_id, {col} FROM users WHERE user_id IN ({placeholders}) ORDER BY {col} DESC LIMIT 10",
        members_ids,
    ) as cur:
        rows = await cur.fetchall()
    embed = discord.Embed(color=COLOR, title=title)
    if not rows:
        embed.description = f"{DOT} No data yet."
    else:
        lines = []
        for uid, val in rows:
            m = guild.get_member(uid)
            name = m.name if m else f"Unknown ({uid})"
            lines.append(f"{DOT} **{name}** • **{val}**")
        embed.description = "\n".join(lines)
    embed.set_footer(text=f"Updated at {datetime.now().strftime('%I:%M %p')}")
    return embed
