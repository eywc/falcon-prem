"""
Shared embed helpers and color scheme.
"""
import discord
from config import COLOR
from utils.emojis import DOT


def base_embed(**kwargs) -> discord.Embed:
    """Create an embed with the standard Falcon yellow color."""
    kwargs.setdefault("color", COLOR)
    return discord.Embed(**kwargs)


def success(description: str) -> discord.Embed:
    return discord.Embed(color=COLOR, description=f"{DOT} {description}")


def error(title: str, description: str = None) -> discord.Embed:
    e = discord.Embed(color=COLOR, title=title)
    if description:
        e.description = description
    return e
