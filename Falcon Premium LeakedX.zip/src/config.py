"""
Configuration loader for Falcon Premium Bot.
All secrets and tunable values come from environment / .env.
"""
import os
import re
import sys
from pathlib import Path

from dotenv import load_dotenv

# Project root = parent of src/
PROJECT_ROOT = Path(__file__).resolve().parent.parent
load_dotenv(PROJECT_ROOT / ".env")


def _env(key: str, default: str = "") -> str:
    return os.getenv(key, default).strip()


BOT_TOKEN = _env("DISCORD_TOKEN")
CLIENT_ID = _env("CLIENT_ID")
SUPPORT_SERVER_URL = _env("SUPPORT_SERVER_URL", "https://discord.gg/LeakX")
VOTE_URL = _env("VOTE_URL", "https://top.gg")
DASHBOARD_URL = _env("DASHBOARD_URL", "https://discord.com")
TOS_URL = _env("TOS_URL", "https://discord.com/terms")
PRIVACY_URL = _env("PRIVACY_URL", "https://discord.com/privacy")
DB_PATH = _env("DB_PATH", "src/data/falcon_data.db")
AUTO_RESTART = _env("AUTO_RESTART", "false").lower() in ("1", "true", "yes", "on")

# Resolve DB path relative to project root
if not os.path.isabs(DB_PATH):
    DB_PATH = str(PROJECT_ROOT / DB_PATH)

# Owner IDs
_raw_owners = _env("OWNER_IDS")
PRIMARY_OWNER_IDS = [int(x) for x in re.split(r"[,\s]+", _raw_owners) if x.strip().isdigit()]
PRIMARY_OWNER_ID = PRIMARY_OWNER_IDS[0] if PRIMARY_OWNER_IDS else None

# Prefix & color
DEFAULT_PREFIX = ","
COLOR = 0xFFDD00


def validate_config() -> None:
    """Exit with a clean purple message if required env vars are missing."""
    from utils.logger import log_error, _supports_color, PURPLE, RESET, BOLD

    missing = []
    if not BOT_TOKEN:
        missing.append("DISCORD_TOKEN")
    if not PRIMARY_OWNER_IDS:
        missing.append("OWNER_IDS")

    if missing:
        msg = f"Missing required environment variable(s): {', '.join(missing)}"
        if _supports_color():
            print(f"{PURPLE}{BOLD}[ERROR]{RESET} {PURPLE}{msg}{RESET}", file=sys.stderr)
            print(f"{PURPLE}Set them in .env (see .env.example).{RESET}", file=sys.stderr)
        else:
            print(f"[ERROR] {msg}", file=sys.stderr)
            print("Set them in .env (see .env.example).", file=sys.stderr)
        sys.exit(1)
