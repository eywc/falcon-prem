"""
Falcon Premium Bot — core entry (bot class, setup_hook, cog loader, global events).
"""
import asyncio
import os
import sys
from collections import defaultdict, deque
from pathlib import Path

import discord
from discord.ext import commands

# Ensure src is on path when imported from run.py
_SRC = Path(__file__).resolve().parent
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from config import (
    BOT_TOKEN,
    PRIMARY_OWNER_ID,
    PRIMARY_OWNER_IDS,
    DEFAULT_PREFIX,
    COLOR,
    validate_config,
)
from utils.database import init_db, build_lb_embed
from utils.logger import log_info, log_error, log_warning
from utils.emojis import DOT

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.invites = True
intents.presences = True


class FalconBot(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix=self.get_prefix, intents=intents, help_command=None)
        self.inv_cache = {}
        self.db = None
        self.owner_id = PRIMARY_OWNER_ID
        self.owner_ids = set(PRIMARY_OWNER_IDS)
        # In-memory anti-raid / anti-nuke trackers
        self.recent_joins = defaultdict(lambda: deque(maxlen=50))
        self.recent_channel_deletes = defaultdict(lambda: deque(maxlen=50))
        self.recent_role_deletes = defaultdict(lambda: deque(maxlen=50))
        self.recent_bans = defaultdict(lambda: deque(maxlen=50))
        # Music: per-guild queues
        self.music_queues = defaultdict(list)
        self.now_playing = {}
        # Color scheme
        self.color = COLOR
        # Cog load stats (filled by loader)
        self._cogs_loaded = 0
        self._cogs_total = 0
        self._cogs_failed = []

    async def get_prefix(self, message):
        if self.db:
            async with self.db.execute(
                "SELECT expiry FROM noprefix WHERE user_id = ?", (message.author.id,)
            ) as cursor:
                row = await cursor.fetchone()
                if row:
                    import datetime
                    expiry = datetime.datetime.fromisoformat(row[0])
                    if datetime.datetime.now() < expiry:
                        return [DEFAULT_PREFIX, ""]
        return [DEFAULT_PREFIX]

    async def setup_hook(self):
        await init_db(self)
        await self.load_cogs()
        try:
            await self.tree.sync()
        except Exception as e:
            log_warning(f"Slash command sync failed: {e}")
        self.loop.create_task(self.daily_reset_task())
        self.loop.create_task(self.live_lb_update_task())

    async def load_cogs(self):
        cogs_dir = Path(__file__).resolve().parent / "cogs"
        cog_files = sorted(
            f.stem for f in cogs_dir.glob("*.py") if f.stem != "__init__" and not f.stem.startswith("_")
        )
        self._cogs_total = len(cog_files)
        self._cogs_loaded = 0
        self._cogs_failed = []
        for name in cog_files:
            ext = f"cogs.{name}"
            try:
                await self.load_extension(ext)
                self._cogs_loaded += 1
                log_info(f"Loaded cog: {name}")
            except Exception as e:
                self._cogs_failed.append(name)
                log_error(f"Failed to load cog {name}: {e}")

    async def daily_reset_task(self):
        import datetime
        while True:
            now = datetime.datetime.now()
            tomorrow = datetime.datetime.combine(
                now.date() + datetime.timedelta(days=1), datetime.time(0, 0)
            )
            await asyncio.sleep((tomorrow - now).total_seconds())
            await self.db.execute("UPDATE users SET today_msgs = 0, voice_daily = 0")
            await self.db.commit()

    async def live_lb_update_task(self):
        while True:
            await asyncio.sleep(30)
            try:
                async with self.db.execute(
                    "SELECT guild_id, channel_id, message_id, lb_type FROM live_leaderboards"
                ) as cur:
                    rows = await cur.fetchall()
                for guild_id, channel_id, message_id, lb_type in rows:
                    guild = self.get_guild(guild_id)
                    if not guild:
                        continue
                    channel = guild.get_channel(channel_id)
                    if not channel:
                        continue
                    try:
                        msg = await channel.fetch_message(message_id)
                        embed = await build_lb_embed(self, guild, lb_type)
                        await msg.edit(embed=embed)
                    except Exception:
                        pass
            except Exception:
                pass

    async def close(self):
        if self.db:
            try:
                await self.db.close()
                log_info("Database connection closed.")
            except Exception:
                pass
        await super().close()


bot = FalconBot()


@bot.check
async def block_blacklisted_users(ctx):
    """Global check: blacklisted users cannot run any commands."""
    from utils.checks import is_bot_blacklisted
    if await is_bot_blacklisted(bot, ctx.author.id):
        return False
    return True


@bot.event
async def on_command_error(ctx, error):
    error = getattr(error, "original", error)

    if isinstance(error, commands.CommandNotFound):
        return
    if isinstance(error, commands.CheckFailure):
        return
    if isinstance(error, commands.MissingPermissions):
        return
    if isinstance(error, commands.MissingRequiredArgument):
        embed = discord.Embed(color=COLOR, title="❌ Missing Arguments")
        embed.description = f"**Command:** `{DEFAULT_PREFIX}{ctx.command.name}`\n\n**Missing:** `{error.param.name}`"
        embed.add_field(
            name="Usage:",
            value=f"`{ctx.prefix}{ctx.command.name} {ctx.command.signature}`",
            inline=False,
        )
        embed.add_field(
            name="Help:",
            value=f"{ctx.command.help or 'No description available.'}",
            inline=False,
        )
        return await ctx.send(embed=embed)
    if isinstance(error, commands.BadArgument):
        embed = discord.Embed(color=COLOR, title="❌ Invalid Argument")
        embed.description = f"**Command:** `{DEFAULT_PREFIX}{ctx.command.name}`\n\n**Error:** {str(error)}"
        embed.add_field(
            name="Usage:",
            value=f"`{ctx.prefix}{ctx.command.name} {ctx.command.signature}`",
            inline=False,
        )
        return await ctx.send(embed=embed)
    # Silently ignore other errors
    return


@bot.event
async def on_ready():
    await bot.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.watching,
            name="discord.gg/LeakX | ,help",
        )
    )
    for guild in bot.guilds:
        try:
            invs = await guild.invites()
            bot.inv_cache[guild.id] = {i.code: i.uses for i in invs}
        except Exception:
            pass
        # Auto-apply emojis on existing servers if any owner is a member and not already set
        try:
            from cogs.help import get_guild_dropdown_emojis, store_guild_dropdown_emojis
            existing = await get_guild_dropdown_emojis(bot, guild.id)
            if not existing:
                async with bot.db.execute("SELECT user_id FROM bot_owners") as cur:
                    extra_owners = {r[0] for r in await cur.fetchall()}
                owner_ids = extra_owners | set(PRIMARY_OWNER_IDS)
                if any(guild.get_member(oid) for oid in owner_ids):
                    await store_guild_dropdown_emojis(bot, guild)
        except Exception:
            pass
    log_info(f"Falcon™ Premium is live and tracking. Logged in as {bot.user} ({bot.user.id})")


def run_bot():
    validate_config()
    bot.run(BOT_TOKEN, log_handler=None)


if __name__ == "__main__":
    run_bot()
